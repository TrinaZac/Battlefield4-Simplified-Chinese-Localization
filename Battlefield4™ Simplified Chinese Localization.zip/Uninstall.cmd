@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Core\Installer.ps1" -Action Uninstall %*
set "_bf4_exit=%errorlevel%"
if "%~1"=="" pause
exit /b %_bf4_exit%
