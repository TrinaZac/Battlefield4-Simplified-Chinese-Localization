@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer.ps1" -Action Check %*
set "_bf4_exit=%errorlevel%"
if "%~1"=="" pause
exit /b %_bf4_exit%
