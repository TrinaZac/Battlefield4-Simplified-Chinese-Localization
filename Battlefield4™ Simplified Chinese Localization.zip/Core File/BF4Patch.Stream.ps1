﻿# Large BF4DXR1 resources use bounded buffers; no third-party runtime or network.
function Initialize-BF4StreamEngine {
    if('BF4Release.StreamDelta' -as [type]){return}
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
namespace BF4Release {
public static class StreamDelta {
 static void Need(bool ok,string message){if(!ok)throw new InvalidDataException(message);}
 static byte[] Exact(BinaryReader r,int n){byte[] b=r.ReadBytes(n);Need(b.Length==n,"Truncated delta");return b;}
 static bool Equal(byte[] a,byte[] b){if(a.Length!=b.Length)return false;int d=0;for(int i=0;i<a.Length;i++)d|=a[i]^b[i];return d==0;}
 static byte[] Hash(Stream s){using(var h=SHA256.Create())return h.ComputeHash(s);}
 static ulong Var(BinaryReader r){ulong x=0;int shift=0;for(int i=0;i<10;i++){byte b=r.ReadByte();Need(!(i==9 && b>1),"Varint overflow");x|=((ulong)(b&127))<<shift;if((b&128)==0){Need(i==0||b!=0,"Noncanonical varint");return x;}shift+=7;}throw new InvalidDataException("Varint overflow");}
 public static void Apply(string source,string patch,string output) {
  byte[] encoded,body,sourceHash,targetHash,bodyHash;ulong ss,ts,count,bs,cs;
  using(var file=File.OpenRead(patch))using(var r=new BinaryReader(file)){
   Need(Encoding.ASCII.GetString(Exact(r,8))=="BF4DXR1\0","Bad delta magic");
   Need(r.ReadUInt16()==1 && r.ReadUInt16()==1 && r.ReadUInt32()==152,"Unsupported delta header");
   ss=r.ReadUInt64();ts=r.ReadUInt64();sourceHash=Exact(r,32);targetHash=Exact(r,32);bodyHash=Exact(r,32);
   count=r.ReadUInt64();bs=r.ReadUInt64();cs=r.ReadUInt64();
   Need(ss<=Int32.MaxValue && ts<=Int32.MaxValue && bs<=67108864 && cs<=67108864 && count<=1000000,"Delta exceeds bounds");
   Need((ulong)file.Length==152+cs,"Delta length mismatch");encoded=Exact(r,(int)cs);
  }
  using(var input=new MemoryStream(encoded))using(var zip=new DeflateStream(input,CompressionMode.Decompress))using(var expanded=new MemoryStream()){
   byte[] buf=new byte[65536];int n;while((n=zip.Read(buf,0,buf.Length))!=0){Need((ulong)(expanded.Length+n)<=bs,"Inflated body overflow");expanded.Write(buf,0,n);}
   Need((ulong)expanded.Length==bs,"Body length mismatch");body=expanded.ToArray();
  }
  using(var s=new MemoryStream(body))Need(Equal(Hash(s),bodyHash),"Command-body hash mismatch");
  using(var src=File.Open(source,FileMode.Open,FileAccess.Read,FileShare.Read)){
   Need((ulong)src.Length==ss && Equal(Hash(src),sourceHash),"Source hash mismatch");
   using(var dst=File.Open(output,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var cmds=new MemoryStream(body))using(var r=new BinaryReader(cmds)){
    byte[] chunk=new byte[65536];ulong done=0;bool ended=false;
    while(cmds.Position<cmds.Length){byte op=r.ReadByte();if(op==0){ended=true;break;}Need(done<count,"Too many commands");done++;
     ulong off=0,len;if(op==1||op==3){off=Var(r);len=Var(r);Need(off<=ss && len<=ss-off,"Source range invalid");src.Position=(long)off;}
     else {Need(op==2,"Unknown opcode");len=Var(r);}
     Need(len>0 && (ulong)dst.Length<=ts && len<=ts-(ulong)dst.Length,"Output range invalid");
     if(op==2||op==3)Need(len<=(ulong)(cmds.Length-cmds.Position),"Truncated literal or XOR");
     while(len>0){int n=(int)Math.Min((ulong)chunk.Length,len);
      if(op==2){byte[] literal=Exact(r,n);dst.Write(literal,0,n);}
      else {int got=0;while(got<n){int q=src.Read(chunk,got,n-got);Need(q>0,"Short source read");got+=q;}
       if(op==3){byte[] mask=Exact(r,n);for(int i=0;i<n;i++)chunk[i]^=mask[i];}dst.Write(chunk,0,n);}
      len-=(ulong)n;
     }
    }
    Need(ended && done==count && cmds.Position==cmds.Length && (ulong)dst.Length==ts,"Incomplete or trailing commands");dst.Flush(true);
   }
  }
  using(var result=File.OpenRead(output))Need(Equal(Hash(result),targetHash),"Target hash mismatch");
 }
}}
'@
}

function New-BF4StreamDeltaStage {
    param([string]$Target,[string]$Patch,[string]$ExpectedHash)
    Initialize-BF4StreamEngine
    $stage=[IO.Path]::Combine([IO.Path]::GetDirectoryName($Target),('.bf4sc-'+[Guid]::NewGuid().ToString('N')+'.stage'))
    try {
        [BF4Release.StreamDelta]::Apply($Target,$Patch,$stage)
        if((Get-BF4Sha256Hex -Path $stage) -ne $ExpectedHash){throw 'Streamed stage hash mismatch.'}
        return $stage
    }catch {
        if([IO.File]::Exists($stage)){[IO.File]::Delete($stage)}
        throw
    }
}
