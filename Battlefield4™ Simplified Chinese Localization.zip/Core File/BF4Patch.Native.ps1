﻿# Native Scaleform font support. Only the Chinese font bundle and one owned
# catalog record per layer are changed; existing CAS bytes are never rewritten.
function Initialize-BF4NativeHelpers {
 if ('BF4Release.NativeBytes' -as [type]) { return }
 Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
namespace BF4Release {
 public sealed class NativeUiState { public string Kind; public byte[] SourceBytes,TargetBytes; }
 public static class NativeBytes {
  static bool Equal(byte[] a,int p,byte[] b) { if(p+b.Length>a.Length)return false;for(int i=0;i<b.Length;i++)if(a[p+i]!=b[i])return false;return true; }
  static int Unique(byte[] a,byte[] b) {
   if(b==null || b.Length<16)throw new InvalidDataException("Invalid font bundle");
   int found=-1;for(int p=0;p<=a.Length-b.Length;p++)if(Equal(a,p,b)){if(found>=0)throw new InvalidDataException("Duplicate native font bundle");found=p;}return found;
  }
  public static NativeUiState Ui(byte[] a,byte[] source,byte[] target) {
   if(source.Length!=target.Length)throw new InvalidDataException("Font bundle size changed");
   int s=Unique(a,source),t=Unique(a,target);
   if((s<0)==(t<0))throw new InvalidDataException("游戏内中文字体资源缺失或与其他修改冲突，请使用匹配的原版资源后重试");
   int p=s>=0?s:t;NativeUiState r=new NativeUiState();r.Kind=s>=0?"Source":"Target";
   r.SourceBytes=(byte[])a.Clone();r.TargetBytes=(byte[])a.Clone();
   Buffer.BlockCopy(source,0,r.SourceBytes,p,source.Length);Buffer.BlockCopy(target,0,r.TargetBytes,p,target.Length);return r;
  }
  public static int CatalogAt(byte[] a,byte[] key) {
   if(a.Length<16 || (a.Length-16)%32!=0 || Encoding.ASCII.GetString(a,0,16)!="NyanNyanNyanNyan" || key.Length!=20)
    throw new InvalidDataException("Invalid native font catalog");
   int found=-1;for(int p=16;p<a.Length;p+=32)if(Equal(a,p,key)){if(found>=0)throw new InvalidDataException("Duplicate native font catalog key");found=p;}return found;
  }
  public static byte[] Without(byte[] a,int p) { if(p<0)return (byte[])a.Clone();byte[] r=new byte[a.Length-32];Buffer.BlockCopy(a,0,r,0,p);Buffer.BlockCopy(a,p+32,r,p,a.Length-p-32);return r; }
  public static byte[] With(byte[] a,byte[] key,uint offset,uint size,uint cas) {
   int p=CatalogAt(a,key);
   if(p>=0){if(BitConverter.ToUInt32(a,p+20)!=offset || BitConverter.ToUInt32(a,p+24)!=size || BitConverter.ToUInt32(a,p+28)!=cas)throw new InvalidDataException("Native font catalog location changed");return (byte[])a.Clone();}
   byte[] r=new byte[a.Length+32];Buffer.BlockCopy(a,0,r,0,a.Length);Buffer.BlockCopy(key,0,r,a.Length,20);
   Buffer.BlockCopy(BitConverter.GetBytes(offset),0,r,a.Length+20,4);Buffer.BlockCopy(BitConverter.GetBytes(size),0,r,a.Length+24,4);Buffer.BlockCopy(BitConverter.GetBytes(cas),0,r,a.Length+28,4);return r;
  }
  public static byte[] ReadRange(string path,long offset,int size) {
   using(FileStream f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)){
    if(offset<0 || offset+size>f.Length)throw new InvalidDataException("Native font CAS block is missing");
    f.Position=offset;byte[] r=new byte[size];int p=0,n;while(p<size && (n=f.Read(r,p,size-p))>0)p+=n;if(p!=size)throw new EndOfStreamException();return r;
   }
  }
  public static void Append(string path,long offset,byte[] block) {
   using(FileStream f=new FileStream(path,FileMode.Open,FileAccess.ReadWrite,FileShare.Read)){
    if(f.Length!=offset)throw new InvalidDataException("CAS length changed before append");f.Position=offset;f.Write(block,0,block.Length);f.Flush(true);
   }
  }
  public static void Truncate(string path,long expected,long size) {
   using(FileStream f=new FileStream(path,FileMode.Open,FileAccess.ReadWrite,FileShare.Read)){
    if(f.Length!=expected)throw new InvalidDataException("CAS length changed before restore");f.SetLength(size);f.Flush(true);
   }
  }
 }
}
'@
}

function Read-BF4NativeManifest {
 param([string]$PackageRoot)
 Initialize-BF4NativeHelpers
 $m=Read-JsonFile (Join-Path $PackageRoot 'native-fonts.json')
 if($m.format -ne 'bf4-native-font-support' -or $m.version -ne 1 -or @($m.layers).Count -ne 2 -or
    $m.font_block_size -lt 100 -or $m.font_block_size -gt 8388608 -or $m.font_block_sha1 -notmatch '^[A-Fa-f0-9]{40}$' -or
    $m.font_block_path -ne 'patches/native-font.casblock'){throw 'Invalid native font manifest.'}
 $specs=@(
  @('base','Data/Win32/UI.sb','Data/cas.cat','Data/cas_16.cas',16),
  @('update','Update/Patch/Data/Win32/UI.sb','Update/Patch/Data/cas.cat','Update/Patch/Data/cas_10.cas',10))
 for($i=0;$i -lt 2;$i++){
  $l=$m.layers[$i];$s=$specs[$i]
  if($l.name -ne $s[0] -or $l.ui_path -ne $s[1] -or $l.catalog_path -ne $s[2] -or $l.cas_path -ne $s[3] -or $l.cas_index -ne $s[4]){throw 'Unsafe native font target path.'}
  $a=[Convert]::FromBase64String($l.source_bundle_base64);$b=[Convert]::FromBase64String($l.target_bundle_base64)
  if($a.Length -lt 100 -or $a.Length -gt 65536 -or $a.Length -ne $b.Length -or
    (Get-BF4Sha256Hex -Bytes $a) -ne $l.source_bundle_sha256 -or (Get-BF4Sha256Hex -Bytes $b) -ne $l.target_bundle_sha256){throw 'Invalid native font bundle patch.'}
 }
 $block=Resolve-BF4ContainedPath $PackageRoot $m.font_block_path;Assert-RegularTargetFile $block
 if((Get-Item -LiteralPath $block).Length -ne $m.font_block_size -or (Get-BF4Sha256Hex -Path $block) -ne $m.font_block_sha256){throw 'Native font payload is damaged.'}
 return $m
}

function Get-BF4NativeUi {
 param([byte[]]$Bytes,[object]$Layer)
 return [BF4Release.NativeBytes]::Ui($Bytes,[Convert]::FromBase64String($Layer.source_bundle_base64),[Convert]::FromBase64String($Layer.target_bundle_base64))
}
function Get-BF4NativeKey {
 param([object]$Manifest)
 $hex=[string]$Manifest.font_block_sha1
 return ,([byte[]]@(for($i=0;$i -lt 40;$i+=2){[Convert]::ToByte($hex.Substring($i,2),16)}))
}
function Get-BF4NativeRoot {
 param([object]$Context)
 return (Resolve-BF4ContainedPath $Context.StateInstanceRoot 'native-fonts')
}
function Read-BF4NativeState {
 param([object]$Context)
 $path=Join-Path (Get-BF4NativeRoot $Context) 'current.json'
 if(-not [IO.File]::Exists($path)){return $null}
 Assert-RegularTargetFile $path
 $s=Read-JsonFile $path
 if($s.schema -ne 1 -or $s.game_root -ne $Context.GameRoot -or $s.twinkle_root -ne $Context.TwinkleRoot -or
    $s.status -notin @('installed','uninstalled','rolled_back')){throw 'Native font state does not match this game.'}
 return $s
}
function Get-BF4NativeLayer {
 param([object]$Manifest,[object]$Layer,[object]$Context,[object]$Saved)
 $ui=Resolve-TargetPath 'game' $Layer.ui_path $Context
 $cat=Resolve-TargetPath 'game' $Layer.catalog_path $Context
 $cas=Resolve-TargetPath 'game' $Layer.cas_path $Context
 foreach($p in @($ui,$cat,$cas)){Assert-RegularTargetFile $p}
 $uiBytes=[IO.File]::ReadAllBytes($ui);$uiState=Get-BF4NativeUi $uiBytes $Layer
 $catBytes=[IO.File]::ReadAllBytes($cat);$key=Get-BF4NativeKey $Manifest
 $at=[BF4Release.NativeBytes]::CatalogAt($catBytes,$key)
 $length=(Get-Item -LiteralPath $cas).Length
 if($null -ne $Saved){$offset=[long]$Saved.offset}
 elseif($at -ge 0){throw 'Native font resources exist without their recovery record.'}
 else{$offset=[long]$length}
 if($offset -lt 16 -or $offset -gt [uint32]::MaxValue){throw 'Invalid native font CAS offset.'}
 if($at -ge 0){
  if([BitConverter]::ToUInt32($catBytes,$at+20) -ne $offset -or
     [BitConverter]::ToUInt32($catBytes,$at+24) -ne $Manifest.font_block_size -or
     [BitConverter]::ToUInt32($catBytes,$at+28) -ne $Layer.cas_index){throw 'Native font catalog record was modified.'}
 }
 $blockState='Source'
 if($length -ge ($offset+[long]$Manifest.font_block_size)){
  $stored=[BF4Release.NativeBytes]::ReadRange($cas,$offset,[int]$Manifest.font_block_size)
  if((Get-BF4Sha256Hex -Bytes $stored) -eq $Manifest.font_block_sha256){$blockState='Target'}
  elseif($at -ge 0 -or $uiState.Kind -eq 'Target'){throw '游戏内字体数据已被其他修改覆盖，请恢复匹配的原版资源后重试。'}
  else{$offset=[long]$length}
 } elseif($length -ne $offset){throw 'Native font CAS was truncated or partially changed.'}
 $without=[BF4Release.NativeBytes]::Without($catBytes,$at)
 $with=[BF4Release.NativeBytes]::With($catBytes,$key,[uint32]$offset,[uint32]$Manifest.font_block_size,[uint32]$Layer.cas_index)
 return [pscustomobject]@{Layer=$Layer;UiPath=$ui;CatPath=$cat;CasPath=$cas;UiBytes=$uiBytes;UiState=$uiState;CatBytes=$catBytes;CatSource=$without;CatTarget=$with;CatKind=$(if($at -ge 0){'Target'}else{'Source'});BlockKind=$blockState;Offset=$offset;CasLength=[long]$length}
}
function Test-BF4NativeBackups {
 param([object]$State,[object]$Context)
 if($null -eq $State -or @($State.layers).Count -ne 2){throw 'Native font recovery backups are missing.'}
 foreach($s in $State.layers){
  $p=Resolve-BF4ContainedPath (Get-BF4NativeRoot $Context) $s.original_ui_backup
  Assert-RegularTargetFile $p
  if((Get-BF4Sha256Hex -Path $p) -ne $s.original_ui_sha256){throw 'Native font original UI backup is damaged.'}
 }
}
function Get-BF4NativeSavedLayer {
 param([object]$State,[string]$Name)
 if($null -eq $State -or $State.status -eq 'rolled_back'){return $null}
 $items=@($State.layers | Where-Object {$_.name -eq $Name})
 if($items.Count -ne 1){throw 'Native font state has missing or duplicate layers.'}
 return $items[0]
}
function Restore-BF4NativeJournal {
 param([object]$Journal,[object]$Manifest,[object]$Context)
 $root=Get-BF4NativeRoot $Context
 if($Journal.schema -ne 1 -or $Journal.game_root -ne $Context.GameRoot -or $Journal.twinkle_root -ne $Context.TwinkleRoot -or
    $Journal.id -notmatch '^native-[0-9a-f]{32}$' -or @($Journal.rows).Count -ne 2){throw 'Invalid native font recovery journal.'}
 $block=[IO.File]::ReadAllBytes((Resolve-BF4ContainedPath $script:PackageRoot $Manifest.font_block_path))
 foreach($r in @($Journal.rows | Sort-Object name -Descending)){
  $l=@($Manifest.layers | Where-Object {$_.name -eq $r.name})
  if($l.Count -ne 1){throw 'Unknown native font recovery layer.'}
  foreach($kind in @('ui','catalog')){
   $relative=if($kind -eq 'ui'){$l[0].ui_path}else{$l[0].catalog_path}
   $p=Resolve-TargetPath 'game' $relative $Context
   $before=[string]$r.($kind+'_before_sha256');$after=[string]$r.($kind+'_after_sha256')
   $backup=Resolve-BF4ContainedPath $root ('transactions/'+$Journal.id+'/'+$r.name+'-'+$kind+'.before')
   Assert-RegularTargetFile $backup
   if((Get-BF4Sha256Hex -Path $backup) -ne $before){throw 'Native font recovery snapshot is damaged.'}
   $now=Get-BF4Sha256Hex -Path $p
   if($now -eq $before){continue}
   if($now -ne $after){throw 'External UI/catalog change prevents native font rollback.'}
   $stage=New-CopyStageFile $p $backup $before
   Invoke-AtomicReplace $stage $p ($r.($kind+'_metadata')) $after $before $null
  }
  $cas=Resolve-TargetPath 'game' $l[0].cas_path $Context
  $len=(Get-Item -LiteralPath $cas).Length
  if($Journal.action -eq 'Install' -and $r.append -and $len -gt $r.cas_before_length){
   $count=[int]($len-[long]$r.cas_before_length)
   if($count -gt $block.Length){throw 'External CAS append prevents native font rollback.'}
   $partial=[BF4Release.NativeBytes]::ReadRange($cas,[long]$r.cas_before_length,$count)
   for($i=0;$i -lt $count;$i++){if($partial[$i] -ne $block[$i]){throw 'External CAS bytes prevent native font rollback.'}}
   [BF4Release.NativeBytes]::Truncate($cas,$len,[long]$r.cas_before_length)
  }
  if($Journal.action -eq 'Uninstall' -and $r.truncate -and $len -eq $r.offset){
   [BF4Release.NativeBytes]::Append($cas,[long]$r.offset,$block)
  }
 }
 $previous=$Journal.previous_state
 if($null -eq $previous){$previous=[pscustomobject]@{schema=1;game_root=$Context.GameRoot;twinkle_root=$Context.TwinkleRoot;status='rolled_back';layers=@()}}
 Write-DurableJson (Join-Path $root 'current.json') $previous
 $Journal.status='rolled_back'
 Write-DurableJson (Join-Path $root 'pending.json') $Journal
 Write-DurableJson (Resolve-BF4ContainedPath $root ('transactions/'+$Journal.id+'/journal.json')) $Journal
}
function Invoke-BF4NativeActionImpl {
 param([ValidateSet('Install','Check','Repair','Uninstall','Preflight')][string]$Action,[object]$Context,[string]$PackageRoot)
 $script:PackageRoot=$PackageRoot
 $m=Read-BF4NativeManifest $PackageRoot
 $root=Get-BF4NativeRoot $Context;$pendingPath=Join-Path $root 'pending.json'
 if([IO.File]::Exists($pendingPath)){
  $pending=Read-JsonFile $pendingPath
  if($pending.status -notin @('installed','uninstalled','rolled_back')){
   if($Action -in @('Check','Preflight')){throw '游戏内字体操作曾被中断，请先运行 Repair.cmd 恢复。'}
   Restore-BF4NativeJournal $pending $m $Context
  }
 }
 $state=Read-BF4NativeState $Context
 $plans=@()
 foreach($l in $m.layers){
  $saved=Get-BF4NativeSavedLayer $state $l.name
  $plans+=Get-BF4NativeLayer $m $l $Context $saved
 }
 # Validate both layers and recovery backups before the text transaction writes.
 if($Action -eq 'Preflight'){
  if($null -ne $state -and $state.status -eq 'installed'){Test-BF4NativeBackups $state $Context}
  return
 }
 $healthy=($null -ne $state -and $state.status -eq 'installed')
 foreach($p in $plans){if($p.UiState.Kind -ne 'Target' -or $p.CatKind -ne 'Target' -or $p.BlockKind -ne 'Target'){$healthy=$false}}
 if($Action -eq 'Check'){
  if(-not $healthy){throw 'INCOMPLETE: 游戏内字体支持缺失，请运行 Repair.cmd 修复。'}
  Test-BF4NativeBackups $state $Context
  Write-BF4Status '游戏内简体字形和字体卸载备份完整。'
  return
 }
 if($Action -ne 'Uninstall' -and $healthy){Test-BF4NativeBackups $state $Context;Write-BF4Status '游戏内简体字体完整。';return}
 if($null -ne $state -and $state.status -eq 'installed'){Test-BF4NativeBackups $state $Context}
 if($Action -eq 'Uninstall' -and ($null -eq $state -or $state.status -ne 'installed')){
  foreach($p in $plans){if($p.UiState.Kind -ne 'Source' -or $p.CatKind -ne 'Source'){throw 'Unmanaged native font changes cannot be uninstalled.'}}
  return
 }
 Assert-NoGameProcesses
 $drive=New-Object IO.DriveInfo([IO.Path]::GetPathRoot($root))
 if($drive.AvailableFreeSpace -lt 67108864){throw 'Insufficient space for native font recovery snapshots.'}
 $id='native-'+[guid]::NewGuid().ToString('N')
 $tx=Resolve-BF4ContainedPath $root ('transactions/'+$id)
 [void](Assert-LocalNtfsPath -Path $Context.StateInstanceRoot -AllowMissingLeaf)
 [void](New-Item -ItemType Directory -Path $tx -Force)
 $rows=@();$nextLayers=@()
 foreach($p in $plans){
  $name=$p.Layer.name
  $uiAfter=if($Action -eq 'Uninstall'){$p.UiState.SourceBytes}else{$p.UiState.TargetBytes}
  $catAfter=if($Action -eq 'Uninstall'){$p.CatSource}else{$p.CatTarget}
  Write-DurableBytes -Path (Join-Path $tx ($name+'-ui.before')) -Bytes $p.UiBytes -CreateNew
  Write-DurableBytes -Path (Join-Path $tx ($name+'-catalog.before')) -Bytes $p.CatBytes -CreateNew
  $saved=Get-BF4NativeSavedLayer $state $name
  if($null -ne $saved -and $state.status -eq 'installed'){
   $original=$saved.original_ui_backup;$originalHash=$saved.original_ui_sha256
  }else{
   $original='transactions/'+$id+'/'+$name+'-ui.original'
   Write-DurableBytes -Path (Resolve-BF4ContainedPath $root $original) -Bytes $p.UiState.SourceBytes -CreateNew
   $originalHash=Get-BF4Sha256Hex -Bytes $p.UiState.SourceBytes
  }
  $nextLayers+=[pscustomobject]@{name=$name;offset=[long]$p.Offset;original_ui_backup=$original;original_ui_sha256=$originalHash}
  $rows+=[pscustomobject]@{name=$name;offset=[long]$p.Offset;cas_before_length=$p.CasLength;append=($p.BlockKind -eq 'Source');truncate=($p.BlockKind -eq 'Target' -and $p.CasLength -eq ($p.Offset+[long]$m.font_block_size));ui_before_sha256=(Get-BF4Sha256Hex -Bytes $p.UiBytes);ui_after_sha256=(Get-BF4Sha256Hex -Bytes $uiAfter);catalog_before_sha256=(Get-BF4Sha256Hex -Bytes $p.CatBytes);catalog_after_sha256=(Get-BF4Sha256Hex -Bytes $catAfter);ui_metadata=(Get-FileMetadata $p.UiPath);catalog_metadata=(Get-FileMetadata $p.CatPath)}
 }
 $journal=[pscustomobject]@{schema=1;font_block_sha256=$m.font_block_sha256;id=$id;action=$(if($Action -eq 'Uninstall'){'Uninstall'}else{'Install'});status='prepared';game_root=$Context.GameRoot;twinkle_root=$Context.TwinkleRoot;previous_state=$state;rows=$rows;created_utc=(Get-Date).ToUniversalTime().ToString('o');failure=$null}
 Write-DurableJson (Join-Path $tx 'journal.json') $journal
 Write-DurableJson $pendingPath $journal
 $block=[IO.File]::ReadAllBytes((Resolve-BF4ContainedPath $PackageRoot $m.font_block_path))
 try {
  if($Action -ne 'Uninstall'){
   foreach($p in $plans){if($p.BlockKind -eq 'Source'){[BF4Release.NativeBytes]::Append($p.CasPath,$p.Offset,$block)}}
  }
  foreach($p in $plans){
   $r=@($rows | Where-Object {$_.name -eq $p.Layer.name})[0]
   foreach($kind in @('catalog','ui')){
    Assert-NoGameProcesses
    $path=if($kind -eq 'ui'){$p.UiPath}else{$p.CatPath}
    $bytes=if($kind -eq 'ui'){if($Action -eq 'Uninstall'){$p.UiState.SourceBytes}else{$p.UiState.TargetBytes}}else{if($Action -eq 'Uninstall'){$p.CatSource}else{$p.CatTarget}}
    $before=[string]$r.($kind+'_before_sha256');$after=[string]$r.($kind+'_after_sha256')
    if($before -ne $after){
     if((Get-BF4Sha256Hex -Path $path) -ne $before){throw 'Native font target changed during installation.'}
     $stage=New-StageFile $path $bytes $after
     Invoke-AtomicReplace $stage $path ($r.($kind+'_metadata')) $before $after $null
    }
   }
   if($env:BF4PATCH_NATIVE_TEST_FAIL_AFTER -eq $p.Layer.name){throw 'Injected native font transaction failure.'}
  }
  if($Action -eq 'Uninstall'){
   foreach($p in $plans){
    $r=@($rows | Where-Object {$_.name -eq $p.Layer.name})[0]
    if($r.truncate){[BF4Release.NativeBytes]::Truncate($p.CasPath,$p.CasLength,$p.Offset)}
   }
  }
  $new=[pscustomobject]@{schema=1;game_root=$Context.GameRoot;twinkle_root=$Context.TwinkleRoot;status=$(if($Action -eq 'Uninstall'){'uninstalled'}else{'installed'});layers=$nextLayers;completed_utc=(Get-Date).ToUniversalTime().ToString('o')}
  Write-DurableJson (Join-Path $root 'current.json') $new
  $journal.status=$new.status
  Write-DurableJson (Join-Path $tx 'journal.json') $journal
  Write-DurableJson $pendingPath $journal
  Write-BF4Status $(if($Action -eq 'Uninstall'){'游戏内字体已恢复原版。'}else{'游戏内简体字体安装完成。'})
 }
 catch {
  $primary=$_.Exception.Message;$journal.failure=$primary
  try{Restore-BF4NativeJournal $journal $m $Context}
  catch{throw ('Native font rollback needs recovery: '+$_.Exception.Message+'; original error: '+$primary)}
  throw ('Native font operation failed and was rolled back: '+$primary)
 }
}


function Invoke-BF4NativeAction {
 param([ValidateSet('Install','Check','Repair','Uninstall','Preflight')][string]$Action,[object]$Context,[string]$PackageRoot)
 try {
 $legacyFound=$false
 foreach($legacyName in @('native-previous','native-previous-mixed')){
 $legacyRoot=Join-Path $PackageRoot $legacyName
 if([IO.File]::Exists((Join-Path $legacyRoot 'native-fonts.json'))){
  $old=Read-BF4NativeManifest $legacyRoot
  $pendingPath=Join-Path (Get-BF4NativeRoot $Context) 'pending.json'
  if([IO.File]::Exists($pendingPath)){
   $pending=Read-JsonFile $pendingPath
   if($pending.status -notin @('installed','uninstalled','rolled_back')){
    if($pending.PSObject.Properties['font_block_sha256'] -and $pending.font_block_sha256 -eq $old.font_block_sha256){$legacyFound=$true}
    elseif(-not $pending.PSObject.Properties['font_block_sha256']){
     foreach($row in $pending.rows){foreach($layer in $old.layers){
      if($row.name -eq $layer.name -and ($row.ui_before_sha256 -eq $layer.ui_target_sha256 -or $row.ui_after_sha256 -eq $layer.ui_target_sha256)){$legacyFound=$true}
     }}
    }
   }
  }
  foreach($l in $old.layers){
   $cat=Resolve-TargetPath 'game' $l.catalog_path $Context
   if([BF4Release.NativeBytes]::CatalogAt([IO.File]::ReadAllBytes($cat),(Get-BF4NativeKey $old)) -ge 0){$legacyFound=$true}
   try {
    $ui=Get-BF4NativeUi ([IO.File]::ReadAllBytes((Resolve-TargetPath 'game' $l.ui_path $Context))) $l
    if($ui.Kind -eq 'Target'){$legacyFound=$true}
   } catch { }
  }
 }
 if($legacyFound){break}
 }
 if(-not $legacyFound){Invoke-BF4NativeActionImpl $Action $Context $PackageRoot;return}
 if($Action -eq 'Preflight'){Invoke-BF4NativeActionImpl Preflight $Context $legacyRoot;return}
 if($Action -eq 'Check'){throw 'OUTDATED_FONT: 当前字体是需要更新的旧版，请运行 Repair.cmd 更新。'}
 Assert-NoGameProcesses
 $null=Read-BF4NativeManifest $PackageRoot
 Write-BF4Status '正在更新旧版游戏内字体，保留原版恢复备份。'
 Invoke-BF4NativeActionImpl Uninstall $Context $legacyRoot
 if($Action -eq 'Uninstall'){return}
 try {Invoke-BF4NativeActionImpl Install $Context $PackageRoot}
 catch {
  $primary=$_.Exception.Message
  try {Invoke-BF4NativeActionImpl Install $Context $legacyRoot}
  catch {throw ($primary+'; previous font recovery failed: '+$_.Exception.Message)}
  throw $primary
 }
 } finally { $script:PackageRoot=$PackageRoot }
}
