﻿# BF4 Simplified Chinese Patch - shared release primitives.
# Windows PowerShell 5.1 and inbox .NET Framework only.
# This file deliberately contains no install-path discovery or orchestration.

function Get-BF4RequiredProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name
    )

    if ($null -eq $InputObject) {
        throw "Required property '$Name' was requested from a null object."
    }
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property) {
        throw "Required property '$Name' is missing."
    }
    return $property.Value
}

function Convert-BF4UInt64 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [object]$Value,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Label
    )

    if ($null -eq $Value) {
        throw "$Label is null."
    }
    $text = [System.Convert]::ToString(
        $Value,
        [System.Globalization.CultureInfo]::InvariantCulture
    )
    if ($text -notmatch '^(0|[1-9][0-9]*)$') {
        throw "$Label must be a non-negative integer."
    }
    [uint64]$result = 0
    if (-not [uint64]::TryParse(
        $text,
        [System.Globalization.NumberStyles]::None,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [ref]$result
    )) {
        throw "$Label is outside UInt64 range."
    }
    return $result
}

function Convert-BF4HexToBytes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Hex,

        [int]$ExpectedByteCount = -1,

        [string]$Label = 'hex value'
    )

    $normalized = $Hex.Trim()
    if (($normalized.Length % 2) -ne 0 -or $normalized -notmatch '^[0-9A-Fa-f]+$') {
        throw "$Label is not valid hexadecimal."
    }
    if ($ExpectedByteCount -ge 0 -and $normalized.Length -ne ($ExpectedByteCount * 2)) {
        throw "$Label must contain exactly $($ExpectedByteCount * 2) hexadecimal characters."
    }
    [byte[]]$result = New-Object byte[] ($normalized.Length / 2)
    for ($index = 0; $index -lt $result.Length; $index++) {
        $result[$index] = [System.Convert]::ToByte($normalized.Substring($index * 2, 2), 16)
    }
    return ,$result
}

function Convert-BF4BytesToHex {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes
    )

    return ([System.BitConverter]::ToString($Bytes)).Replace('-', '')
}

function Test-BF4ByteArrayEqual {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Left,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Right
    )

    if ($Left.Length -ne $Right.Length) {
        return $false
    }
    [int]$difference = 0
    for ($index = 0; $index -lt $Left.Length; $index++) {
        $difference = $difference -bor ([int]$Left[$index] -bxor [int]$Right[$index])
    }
    return ($difference -eq 0)
}

function Get-BF4Sha256Hex {
    [CmdletBinding(DefaultParameterSetName = 'Bytes')]
    param(
        [Parameter(Mandatory = $true, ParameterSetName = 'Bytes')]
        [AllowEmptyCollection()]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true, ParameterSetName = 'Path')]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        if ($PSCmdlet.ParameterSetName -eq 'Bytes') {
            [byte[]]$digest = $sha256.ComputeHash($Bytes)
        }
        else {
            $fullPath = [System.IO.Path]::GetFullPath($Path)
            if (-not [System.IO.File]::Exists($fullPath)) {
                throw "File does not exist: $fullPath"
            }
            $stream = [System.IO.File]::Open(
                $fullPath,
                [System.IO.FileMode]::Open,
                [System.IO.FileAccess]::Read,
                [System.IO.FileShare]::Read
            )
            try {
                [byte[]]$digest = $sha256.ComputeHash($stream)
            }
            finally {
                $stream.Dispose()
            }
        }
        return (Convert-BF4BytesToHex -Bytes $digest)
    }
    finally {
        $sha256.Dispose()
    }
}

function Assert-BF4SafeRelativePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw 'Relative path is empty.'
    }
    if ([System.IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:') {
        throw "Rooted or drive-relative path is not allowed: $Path"
    }
    if ($Path.IndexOf([char]0) -ge 0) {
        throw 'Relative path contains a NUL character.'
    }

    $normalizedSeparators = $Path.Replace('/', '\')
    [string[]]$segments = $normalizedSeparators.Split([char]'\')
    $safeSegments = New-Object 'System.Collections.Generic.List[string]'
    foreach ($segment in $segments) {
        if ([string]::IsNullOrEmpty($segment) -or $segment -eq '.' -or $segment -eq '..') {
            throw "Relative path contains an empty or traversal segment: $Path"
        }
        if ($segment.EndsWith(' ') -or $segment.EndsWith('.')) {
            throw "Relative path segment has an ambiguous trailing character: $segment"
        }
        if ($segment.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) {
            throw "Relative path segment contains an invalid Windows character: $segment"
        }
        foreach ($character in $segment.ToCharArray()) {
            if ([int]$character -lt 32) {
                throw "Relative path segment contains a control character: $segment"
            }
        }
        $baseName = $segment.Split([char]'.')[0]
        if ($baseName -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') {
            throw "Reserved Windows device name is not allowed: $segment"
        }
        [void]$safeSegments.Add($segment)
    }
    return [string]::Join('\', $safeSegments.ToArray())
}

function Resolve-BF4ContainedPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Root,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$RelativePath
    )

    if (-not [System.IO.Path]::IsPathRooted($Root)) {
        throw "Containment root must be absolute: $Root"
    }
    $safeRelative = Assert-BF4SafeRelativePath -Path $RelativePath
    $rootFull = [System.IO.Path]::GetFullPath($Root)
    $candidate = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($rootFull, $safeRelative))
    $prefix = $rootFull.TrimEnd([char]'\', [char]'/') + [System.IO.Path]::DirectorySeparatorChar
    if (-not $candidate.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Resolved path escapes the containment root: $RelativePath"
    }
    return $candidate
}

function Get-BF4Crc32Bzip2 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes
    )

    [uint32[]]$table = New-Object 'System.UInt32[]' 256
    for ($value = 0; $value -lt 256; $value++) {
        [uint32]$crc = [uint32](([uint64]$value) -shl 24)
        for ($bit = 0; $bit -lt 8; $bit++) {
            if (($crc -band [uint32]2147483648) -ne 0) {
                $crc = [uint32]((([uint64]$crc -shl 1) -band [uint64]4294967295) -bxor [uint64]79764919)
            }
            else {
                $crc = [uint32](([uint64]$crc -shl 1) -band [uint64]4294967295)
            }
        }
        $table[$value] = $crc
    }

    [uint32]$result = [uint32]4294967295
    foreach ($byte in $Bytes) {
        $index = [int](((($result -shr 24) -bxor [uint32]$byte)) -band 255)
        $result = [uint32]((([uint64]$result -shl 8) -band [uint64]4294967295) -bxor [uint64]$table[$index])
    }
    return [uint32]($result -bxor [uint32]4294967295)
}

function Convert-BF4Crc32Value {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [object]$Value,

        [string]$Label = 'CRC32-BZIP2'
    )

    if ($Value -is [string]) {
        $text = ([string]$Value).Trim()
        if ($text -match '^[0-9A-Fa-f]{8}$') {
            return [uint32]::Parse(
                $text,
                [System.Globalization.NumberStyles]::HexNumber,
                [System.Globalization.CultureInfo]::InvariantCulture
            )
        }
    }
    $numeric = Convert-BF4UInt64 -Value $Value -Label $Label
    if ($numeric -gt [uint64]4294967295) {
        throw "$Label is outside UInt32 range."
    }
    return [uint32]$numeric
}

function Read-BF4VersionsBytes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes
    )

    if ($Bytes.Length -eq 0) {
        throw 'versions is empty.'
    }
    if (-not [System.BitConverter]::IsLittleEndian) {
        throw 'versions parsing requires a little-endian runtime.'
    }

    $records = New-Object 'System.Collections.Generic.List[object]'
    $seenPaths = @{}
    [int]$offset = 0
    while ($offset -lt $Bytes.Length) {
        if (($Bytes.Length - $offset) -lt 8) {
            throw "versions header is truncated at byte offset $offset."
        }
        [uint32]$storedCrc = [System.BitConverter]::ToUInt32($Bytes, $offset)
        [uint32]$pathLengthRaw = [System.BitConverter]::ToUInt32($Bytes, $offset + 4)
        if ($pathLengthRaw -eq 0 -or [uint64]$pathLengthRaw -gt [uint64][int]::MaxValue) {
            throw "versions has an invalid path length at byte offset $offset."
        }
        [int]$pathLength = [int]$pathLengthRaw
        [uint64]$pathEndWide = [uint64]$offset + [uint64]8 + [uint64]$pathLength
        if ($pathEndWide -gt [uint64]$Bytes.Length) {
            throw "versions path is truncated at byte offset $offset."
        }
        [int]$pathOffset = $offset + 8
        for ($index = $pathOffset; $index -lt [int]$pathEndWide; $index++) {
            if ($Bytes[$index] -gt 127 -or $Bytes[$index] -eq 0) {
                throw "versions path is not non-NUL ASCII at byte offset $pathOffset."
            }
        }
        $path = [System.Text.Encoding]::ASCII.GetString($Bytes, $pathOffset, $pathLength)
        $safePath = Assert-BF4SafeRelativePath -Path $path
        $normalized = $safePath.Replace('\', '/').ToLowerInvariant()
        if ($seenPaths.ContainsKey($normalized)) {
            throw "versions contains a duplicate path: $path"
        }
        $seenPaths[$normalized] = $true
        [void]$records.Add([pscustomobject]@{
            Offset = $offset
            CrcByteOffset = $offset
            PathByteOffset = $pathOffset
            PathByteLength = $pathLength
            Path = $path
            NormalizedPath = $normalized
            StoredCrc32Bzip2 = $storedCrc
            StoredCrc32Bzip2Hex = ('{0:X8}' -f $storedCrc)
        })
        $offset = [int]$pathEndWide
    }
    if ($offset -ne $Bytes.Length) {
        throw 'versions parsing did not consume the complete file.'
    }
    return $records.ToArray()
}

function Update-BF4VersionsCrcBytes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [object[]]$Updates,

        [ValidateRange(1, 1024)]
        [int]$ExpectedUpdateCount = 2
    )

    if ($Updates.Count -ne $ExpectedUpdateCount) {
        throw "Expected exactly $ExpectedUpdateCount versions CRC updates; got $($Updates.Count)."
    }
    $records = @(Read-BF4VersionsBytes -Bytes $Bytes)
    $recordsByPath = @{}
    foreach ($record in $records) {
        $recordsByPath[$record.NormalizedPath] = $record
    }

    [byte[]]$result = New-Object byte[] $Bytes.Length
    [System.Array]::Copy($Bytes, 0, $result, 0, $Bytes.Length)
    $updatedPaths = @{}
    $targetCrcByPath = @{}
    foreach ($update in $Updates) {
        $path = [string](Get-BF4RequiredProperty -InputObject $update -Name 'path')
        $safePath = Assert-BF4SafeRelativePath -Path $path
        $normalized = $safePath.Replace('\', '/').ToLowerInvariant()
        if ($updatedPaths.ContainsKey($normalized)) {
            throw "Duplicate versions CRC update: $path"
        }
        $updatedPaths[$normalized] = $true
        if (-not $recordsByPath.ContainsKey($normalized)) {
            throw "versions path was not found: $path"
        }
        $record = $recordsByPath[$normalized]
        [uint32]$expectedCrc = Convert-BF4Crc32Value -Value (
            Get-BF4RequiredProperty -InputObject $update -Name 'expected_crc32_bzip2'
        ) -Label "expected CRC for $path"
        [uint32]$targetCrc = Convert-BF4Crc32Value -Value (
            Get-BF4RequiredProperty -InputObject $update -Name 'target_crc32_bzip2'
        ) -Label "target CRC for $path"
        if ([uint32]$record.StoredCrc32Bzip2 -ne $expectedCrc) {
            throw ("versions CRC mismatch for {0}: expected {1:X8}, found {2:X8}." -f
                $path, $expectedCrc, [uint32]$record.StoredCrc32Bzip2)
        }
        if ($targetCrc -eq $expectedCrc) {
            throw "versions CRC update is a no-op for $path."
        }
        $targetCrcByPath[$normalized] = $targetCrc
        [byte[]]$replacement = [System.BitConverter]::GetBytes($targetCrc)
        [System.Array]::Copy($replacement, 0, $result, [int]$record.CrcByteOffset, 4)
    }

    $verifiedRecords = @(Read-BF4VersionsBytes -Bytes $result)
    foreach ($verified in $verifiedRecords) {
        if ($updatedPaths.ContainsKey($verified.NormalizedPath)) {
            if ([uint32]$verified.StoredCrc32Bzip2 -ne [uint32]$targetCrcByPath[$verified.NormalizedPath]) {
                throw "Requested versions CRC update was not applied: $($verified.Path)"
            }
            continue
        }
        $before = $recordsByPath[$verified.NormalizedPath]
        if ([uint32]$verified.StoredCrc32Bzip2 -ne [uint32]$before.StoredCrc32Bzip2) {
            throw "An unrequested versions record changed: $($verified.Path)"
        }
    }
    return ,$result
}

function Test-BF4JsonStringToken {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [string]$Token,

        [string]$Label = 'JSON string token'
    )

    if ($Token.Length -lt 2 -or $Token[0] -ne [char]'"' -or $Token[$Token.Length - 1] -ne [char]'"') {
        throw "$Label is not a quoted JSON string token."
    }
    try {
        $decoded = ConvertFrom-Json -InputObject $Token -ErrorAction Stop
    }
    catch {
        throw "$Label is invalid: $($_.Exception.Message)"
    }
    if (-not ($decoded -is [string])) {
        throw "$Label does not decode to a string."
    }
    return $true
}

function Apply-BF4JsonPatchBytes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$SourceBytes,

        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [object]$FilePatch
    )

    $pathLabel = [string](Get-BF4RequiredProperty -InputObject $FilePatch -Name 'path')
    [uint64]$sourceSize = Convert-BF4UInt64 -Value (
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'source_size'
    ) -Label "$pathLabel source_size"
    if ($sourceSize -ne [uint64]$SourceBytes.LongLength) {
        throw "$pathLabel source size mismatch: expected $sourceSize, found $($SourceBytes.LongLength)."
    }
    $expectedSourceHash = [string](
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'source_sha256'
    )
    [void](Convert-BF4HexToBytes -Hex $expectedSourceHash -ExpectedByteCount 32 -Label "$pathLabel source SHA-256")
    $actualSourceHash = Get-BF4Sha256Hex -Bytes $SourceBytes
    if (-not $actualSourceHash.Equals($expectedSourceHash, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "$pathLabel source SHA-256 mismatch: expected $expectedSourceHash, found $actualSourceHash."
    }

    [uint64]$targetSizeWide = Convert-BF4UInt64 -Value (
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'target_size'
    ) -Label "$pathLabel target_size"
    if ($targetSizeWide -gt [uint64][int]::MaxValue) {
        throw "$pathLabel target_size exceeds the in-memory release-core limit."
    }
    [int]$targetSize = [int]$targetSizeWide
    $expectedTargetHash = [string](
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'target_sha256'
    )
    [void](Convert-BF4HexToBytes -Hex $expectedTargetHash -ExpectedByteCount 32 -Label "$pathLabel target SHA-256")

    $changeValue = Get-BF4RequiredProperty -InputObject $FilePatch -Name 'changes'
    [object[]]$changes = @($changeValue)
    [uint64]$declaredChangeCount = Convert-BF4UInt64 -Value (
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'change_count'
    ) -Label "$pathLabel change_count"
    if ($declaredChangeCount -ne [uint64]$changes.Count) {
        throw "$pathLabel change_count does not match its changes array."
    }
    [uint64]$keyCount = Convert-BF4UInt64 -Value (
        Get-BF4RequiredProperty -InputObject $FilePatch -Name 'key_count'
    ) -Label "$pathLabel key_count"
    if ($declaredChangeCount -gt $keyCount) {
        throw "$pathLabel change_count exceeds key_count."
    }

    $utf8 = New-Object System.Text.UTF8Encoding($false, $true)
    $seenKeys = New-Object 'System.Collections.Generic.List[string]'
    $output = New-Object System.IO.MemoryStream
    try {
        [int]$cursor = 0
        foreach ($change in $changes) {
            $key = [string](Get-BF4RequiredProperty -InputObject $change -Name 'key')
            if ([string]::IsNullOrEmpty($key)) {
                throw "$pathLabel contains a change with an empty key."
            }
            if ($seenKeys.Contains($key)) {
                throw "$pathLabel contains a duplicate change key: $key"
            }
            [void]$seenKeys.Add($key)

            [uint64]$offsetWide = Convert-BF4UInt64 -Value (
                Get-BF4RequiredProperty -InputObject $change -Name 'source_value_token_byte_offset'
            ) -Label "$pathLabel/$key source token offset"
            [uint64]$lengthWide = Convert-BF4UInt64 -Value (
                Get-BF4RequiredProperty -InputObject $change -Name 'source_value_token_byte_length'
            ) -Label "$pathLabel/$key source token length"
            if ($offsetWide -gt [uint64][int]::MaxValue -or $lengthWide -gt [uint64][int]::MaxValue) {
                throw "$pathLabel/$key source token span exceeds the in-memory release-core limit."
            }
            [int]$offset = [int]$offsetWide
            [int]$length = [int]$lengthWide
            if ($length -le 0 -or $offset -lt $cursor -or $offset -gt $SourceBytes.Length -or $length -gt ($SourceBytes.Length - $offset)) {
                throw "$pathLabel/$key source token span is empty, overlapping, or out of range."
            }

            [byte[]]$sourceToken = New-Object byte[] $length
            [System.Array]::Copy($SourceBytes, $offset, $sourceToken, 0, $length)
            $expectedTokenHash = [string](
                Get-BF4RequiredProperty -InputObject $change -Name 'source_value_token_sha256'
            )
            [void](Convert-BF4HexToBytes -Hex $expectedTokenHash -ExpectedByteCount 32 -Label "$pathLabel/$key source token SHA-256")
            $actualTokenHash = Get-BF4Sha256Hex -Bytes $sourceToken
            if (-not $actualTokenHash.Equals($expectedTokenHash, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "$pathLabel/$key source token SHA-256 mismatch."
            }
            try {
                $sourceTokenText = $utf8.GetString($sourceToken)
            }
            catch {
                throw "$pathLabel/$key source token is not valid UTF-8: $($_.Exception.Message)"
            }
            [void](Test-BF4JsonStringToken -Token $sourceTokenText -Label "$pathLabel/$key source token")

            $targetToken = [string](
                Get-BF4RequiredProperty -InputObject $change -Name 'target_json_string_token'
            )
            [void](Test-BF4JsonStringToken -Token $targetToken -Label "$pathLabel/$key target token")
            try {
                [byte[]]$targetTokenBytes = $utf8.GetBytes($targetToken)
            }
            catch {
                throw "$pathLabel/$key target token is not valid UTF-8: $($_.Exception.Message)"
            }

            $output.Write($SourceBytes, $cursor, $offset - $cursor)
            $output.Write($targetTokenBytes, 0, $targetTokenBytes.Length)
            $cursor = $offset + $length
            if ($output.Length -gt [int64]$targetSize) {
                throw "$pathLabel patched output exceeds target_size."
            }
        }
        $output.Write($SourceBytes, $cursor, $SourceBytes.Length - $cursor)
        if ($output.Length -gt [int64]$targetSize) {
            throw "$pathLabel patched output exceeds target_size."
        }

        [uint64]$requiredPadding = [uint64]([int64]$targetSize - $output.Length)
        [uint64]$declaredPadding = Convert-BF4UInt64 -Value (
            Get-BF4RequiredProperty -InputObject $FilePatch -Name 'append_ascii_space_count'
        ) -Label "$pathLabel append_ascii_space_count"
        if ($declaredPadding -ne $requiredPadding) {
            throw "$pathLabel trailing ASCII-space count mismatch: expected $declaredPadding, required $requiredPadding."
        }
        while ($output.Length -lt [int64]$targetSize) {
            $output.WriteByte(32)
        }
        [byte[]]$result = $output.ToArray()
    }
    finally {
        $output.Dispose()
    }

    $actualTargetHash = Get-BF4Sha256Hex -Bytes $result
    if (-not $actualTargetHash.Equals($expectedTargetHash, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "$pathLabel target SHA-256 mismatch: expected $expectedTargetHash, found $actualTargetHash."
    }
    return ,$result
}

function Read-BF4UInt16LittleEndian {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [int]$Offset,

        [string]$Label = 'UInt16'
    )

    if ($Offset -lt 0 -or $Offset -gt ($Bytes.Length - 2)) {
        throw "$Label is truncated."
    }
    return [System.BitConverter]::ToUInt16($Bytes, $Offset)
}

function Read-BF4UInt32LittleEndian {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [int]$Offset,

        [string]$Label = 'UInt32'
    )

    if ($Offset -lt 0 -or $Offset -gt ($Bytes.Length - 4)) {
        throw "$Label is truncated."
    }
    return [System.BitConverter]::ToUInt32($Bytes, $Offset)
}

function Read-BF4UInt64LittleEndian {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [int]$Offset,

        [string]$Label = 'UInt64'
    )

    if ($Offset -lt 0 -or $Offset -gt ($Bytes.Length - 8)) {
        throw "$Label is truncated."
    }
    return [System.BitConverter]::ToUInt64($Bytes, $Offset)
}

function Read-BF4UnsignedLeb128 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [int]$Offset
    )

    if ($Offset -lt 0 -or $Offset -gt $Bytes.Length) {
        throw 'Unsigned LEB128 offset is outside the command body.'
    }
    [uint64]$value = 0
    [int]$shift = 0
    [int]$position = $Offset
    for ($index = 0; $index -lt 10; $index++) {
        if ($position -ge $Bytes.Length) {
            throw 'Unsigned LEB128 integer is truncated.'
        }
        [byte]$current = $Bytes[$position]
        $position++
        [uint64]$payload = [uint64]($current -band 127)
        if ($shift -eq 63 -and $payload -gt 1) {
            throw 'Unsigned LEB128 integer overflows UInt64.'
        }
        $value = [uint64]($value -bor [uint64]($payload -shl $shift))
        if (($current -band 128) -eq 0) {
            return [pscustomobject]@{
                Value = $value
                NextOffset = $position
            }
        }
        $shift += 7
    }
    throw 'Unsigned LEB128 integer exceeds ten bytes.'
}

function Expand-BF4RawDeflate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Encoded,

        [Parameter(Mandatory = $true)]
        [int]$ExpectedSize
    )

    if ($ExpectedSize -lt 0) {
        throw 'Expected Deflate output size is negative.'
    }
    $input = New-Object System.IO.MemoryStream
    $output = New-Object System.IO.MemoryStream
    $deflate = $null
    try {
        $input.Write($Encoded, 0, $Encoded.Length)
        $input.Position = 0
        $deflate = New-Object System.IO.Compression.DeflateStream(
            $input,
            [System.IO.Compression.CompressionMode]::Decompress,
            $true
        )
        [byte[]]$buffer = New-Object byte[] 81920
        while ($true) {
            $read = $deflate.Read($buffer, 0, $buffer.Length)
            if ($read -eq 0) {
                break
            }
            $output.Write($buffer, 0, $read)
            if ($output.Length -gt [int64]$ExpectedSize) {
                throw 'Inflated command body exceeds its declared size.'
            }
        }
        if ($output.Length -ne [int64]$ExpectedSize) {
            throw "Inflated command body size mismatch: expected $ExpectedSize, found $($output.Length)."
        }
        [byte[]]$result = $output.ToArray()
        return ,$result
    }
    catch {
        throw "Raw Deflate command body is invalid: $($_.Exception.Message)"
    }
    finally {
        if ($null -ne $deflate) {
            $deflate.Dispose()
        }
        $input.Dispose()
        $output.Dispose()
    }
}

function Write-BF4DeltaOutputChunk {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.MemoryStream]$Output,

        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,

        [Parameter(Mandatory = $true)]
        [int]$Offset,

        [Parameter(Mandatory = $true)]
        [int]$Length,

        [Parameter(Mandatory = $true)]
        [int]$TargetSize
    )

    if ($Length -lt 0 -or $Offset -lt 0 -or $Offset -gt $Bytes.Length -or $Length -gt ($Bytes.Length - $Offset)) {
        throw 'Delta output chunk is outside its byte array.'
    }
    if ($Output.Length + [int64]$Length -gt [int64]$TargetSize) {
        throw 'Delta command stream writes beyond target_size.'
    }
    $Output.Write($Bytes, $Offset, $Length)
}

function Apply-BF4DeltaBytes {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$SourceBytes,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$PatchBytes
    )

    if (-not [System.BitConverter]::IsLittleEndian) {
        throw 'BF4 delta application requires a little-endian runtime.'
    }
    [int]$headerSizeConstant = 152
    if ($PatchBytes.Length -lt $headerSizeConstant) {
        throw 'BF4 delta is shorter than its 152-byte header.'
    }
    [byte[]]$expectedMagic = [System.Text.Encoding]::ASCII.GetBytes("BF4DXR1`0")
    [byte[]]$actualMagic = New-Object byte[] 8
    [System.Array]::Copy($PatchBytes, 0, $actualMagic, 0, 8)
    if (-not (Test-BF4ByteArrayEqual -Left $actualMagic -Right $expectedMagic)) {
        throw 'BF4 delta magic is not BF4DXR1.'
    }

    [uint16]$version = Read-BF4UInt16LittleEndian -Bytes $PatchBytes -Offset 8 -Label 'delta version'
    [uint16]$flags = Read-BF4UInt16LittleEndian -Bytes $PatchBytes -Offset 10 -Label 'delta flags'
    [uint32]$headerSize = Read-BF4UInt32LittleEndian -Bytes $PatchBytes -Offset 12 -Label 'delta header_size'
    if ($version -ne 1) {
        throw "Unsupported BF4 delta version: $version"
    }
    if (($flags -band 65534) -ne 0) {
        throw ('BF4 delta uses unknown flags: 0x{0:X4}' -f $flags)
    }
    if ($headerSize -ne $headerSizeConstant) {
        throw "Unexpected BF4 delta header size: $headerSize"
    }

    [uint64]$sourceSize = Read-BF4UInt64LittleEndian -Bytes $PatchBytes -Offset 16 -Label 'delta source_size'
    [uint64]$targetSizeWide = Read-BF4UInt64LittleEndian -Bytes $PatchBytes -Offset 24 -Label 'delta target_size'
    [uint64]$commandCountWide = Read-BF4UInt64LittleEndian -Bytes $PatchBytes -Offset 128 -Label 'delta command_count'
    [uint64]$bodySizeWide = Read-BF4UInt64LittleEndian -Bytes $PatchBytes -Offset 136 -Label 'delta body_uncompressed_size'
    [uint64]$compressedSizeWide = Read-BF4UInt64LittleEndian -Bytes $PatchBytes -Offset 144 -Label 'delta body_compressed_size'
    if ($sourceSize -ne [uint64]$SourceBytes.LongLength) {
        throw "BF4 delta source size mismatch: expected $sourceSize, found $($SourceBytes.LongLength)."
    }
    if ($targetSizeWide -gt [uint64][int]::MaxValue -or $bodySizeWide -gt [uint64][int]::MaxValue -or $compressedSizeWide -gt [uint64][int]::MaxValue -or $commandCountWide -gt [uint64][int]::MaxValue) {
        throw 'BF4 delta exceeds the in-memory release-core limit.'
    }
    if ([uint64]$headerSize + $compressedSizeWide -ne [uint64]$PatchBytes.LongLength) {
        throw 'BF4 delta byte length does not match its header.'
    }
    [int]$targetSize = [int]$targetSizeWide
    [int]$bodySize = [int]$bodySizeWide
    [int]$compressedSize = [int]$compressedSizeWide
    [int]$commandCount = [int]$commandCountWide

    [byte[]]$expectedSourceHash = New-Object byte[] 32
    [byte[]]$expectedTargetHash = New-Object byte[] 32
    [byte[]]$expectedBodyHash = New-Object byte[] 32
    [System.Array]::Copy($PatchBytes, 32, $expectedSourceHash, 0, 32)
    [System.Array]::Copy($PatchBytes, 64, $expectedTargetHash, 0, 32)
    [System.Array]::Copy($PatchBytes, 96, $expectedBodyHash, 0, 32)
    $actualSourceHash = Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $SourceBytes) -ExpectedByteCount 32
    if (-not (Test-BF4ByteArrayEqual -Left $actualSourceHash -Right $expectedSourceHash)) {
        throw 'BF4 delta source SHA-256 mismatch.'
    }

    [byte[]]$encodedBody = New-Object byte[] $compressedSize
    [System.Array]::Copy($PatchBytes, $headerSizeConstant, $encodedBody, 0, $compressedSize)
    if (($flags -band 1) -ne 0) {
        [byte[]]$body = Expand-BF4RawDeflate -Encoded $encodedBody -ExpectedSize $bodySize
    }
    else {
        if ($compressedSize -ne $bodySize) {
            throw 'Uncompressed BF4 delta body sizes do not match.'
        }
        [byte[]]$body = $encodedBody
    }
    $actualBodyHash = Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $body) -ExpectedByteCount 32
    if (-not (Test-BF4ByteArrayEqual -Left $actualBodyHash -Right $expectedBodyHash)) {
        throw 'BF4 delta command body SHA-256 mismatch.'
    }

    $output = New-Object System.IO.MemoryStream
    try {
        [int]$position = 0
        for ($commandIndex = 0; $commandIndex -lt $commandCount; $commandIndex++) {
            if ($position -ge $body.Length) {
                throw 'BF4 delta command stream ended before command_count.'
            }
            [byte]$opcode = $body[$position]
            $position++
            if ($opcode -eq 1) {
                $offsetResult = Read-BF4UnsignedLeb128 -Bytes $body -Offset $position
                [uint64]$sourceOffsetWide = $offsetResult.Value
                $position = $offsetResult.NextOffset
                $lengthResult = Read-BF4UnsignedLeb128 -Bytes $body -Offset $position
                [uint64]$lengthWide = $lengthResult.Value
                $position = $lengthResult.NextOffset
                if ($lengthWide -eq 0 -or $sourceOffsetWide -gt $sourceSize -or $lengthWide -gt ($sourceSize - $sourceOffsetWide) -or $sourceOffsetWide -gt [uint64][int]::MaxValue -or $lengthWide -gt [uint64][int]::MaxValue) {
                    throw 'BF4 delta COPY range is empty or outside the source.'
                }
                Write-BF4DeltaOutputChunk -Output $output -Bytes $SourceBytes -Offset ([int]$sourceOffsetWide) -Length ([int]$lengthWide) -TargetSize $targetSize
            }
            elseif ($opcode -eq 2) {
                $lengthResult = Read-BF4UnsignedLeb128 -Bytes $body -Offset $position
                [uint64]$lengthWide = $lengthResult.Value
                $position = $lengthResult.NextOffset
                if ($lengthWide -eq 0 -or $lengthWide -gt [uint64][int]::MaxValue -or $position -gt $body.Length -or $lengthWide -gt [uint64]($body.Length - $position)) {
                    throw 'BF4 delta ADD payload is empty or truncated.'
                }
                [int]$length = [int]$lengthWide
                Write-BF4DeltaOutputChunk -Output $output -Bytes $body -Offset $position -Length $length -TargetSize $targetSize
                $position += $length
            }
            elseif ($opcode -eq 3) {
                $offsetResult = Read-BF4UnsignedLeb128 -Bytes $body -Offset $position
                [uint64]$sourceOffsetWide = $offsetResult.Value
                $position = $offsetResult.NextOffset
                $lengthResult = Read-BF4UnsignedLeb128 -Bytes $body -Offset $position
                [uint64]$lengthWide = $lengthResult.Value
                $position = $lengthResult.NextOffset
                if ($lengthWide -eq 0 -or $sourceOffsetWide -gt $sourceSize -or $lengthWide -gt ($sourceSize - $sourceOffsetWide) -or $sourceOffsetWide -gt [uint64][int]::MaxValue -or $lengthWide -gt [uint64][int]::MaxValue -or $position -gt $body.Length -or $lengthWide -gt [uint64]($body.Length - $position)) {
                    throw 'BF4 delta XOR_FROM_SOURCE range is empty or truncated.'
                }
                [int]$sourceOffset = [int]$sourceOffsetWide
                [int]$length = [int]$lengthWide
                [byte[]]$xorResult = New-Object byte[] $length
                for ($index = 0; $index -lt $length; $index++) {
                    $xorResult[$index] = [byte]($SourceBytes[$sourceOffset + $index] -bxor $body[$position + $index])
                }
                Write-BF4DeltaOutputChunk -Output $output -Bytes $xorResult -Offset 0 -Length $length -TargetSize $targetSize
                $position += $length
            }
            else {
                throw ('Unknown BF4 delta opcode: 0x{0:X2}' -f $opcode)
            }
        }
        if ($position -ge $body.Length -or $body[$position] -ne 0) {
            throw 'BF4 delta command stream does not end with END.'
        }
        $position++
        if ($position -ne $body.Length) {
            throw 'BF4 delta command stream has bytes after END.'
        }
        if ($output.Length -ne [int64]$targetSize) {
            throw "BF4 delta target size mismatch: expected $targetSize, found $($output.Length)."
        }
        [byte[]]$result = $output.ToArray()
    }
    finally {
        $output.Dispose()
    }

    $actualTargetHash = Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $result) -ExpectedByteCount 32
    if (-not (Test-BF4ByteArrayEqual -Left $actualTargetHash -Right $expectedTargetHash)) {
        throw 'BF4 delta target SHA-256 mismatch.'
    }
    return ,$result
}

function Get-BF4MetadataDateTimeUtc {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [object]$Ticks,

        [Parameter(Mandatory = $true)]
        [string]$Label
    )

    $ticksWide = Convert-BF4UInt64 -Value $Ticks -Label $Label
    if ($ticksWide -gt [uint64][System.DateTime]::MaxValue.Ticks) {
        throw "$Label is outside DateTime range."
    }
    $value = [System.DateTime]::MinValue.AddTicks([long]$ticksWide)
    return [System.DateTime]::SpecifyKind($value, [System.DateTimeKind]::Utc)
}

function Get-BF4FileMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not [System.IO.File]::Exists($fullPath)) {
        throw "Metadata target file does not exist: $fullPath"
    }
    $file = New-Object System.IO.FileInfo($fullPath)
    $sections = [System.Security.AccessControl.AccessControlSections](
        [int][System.Security.AccessControl.AccessControlSections]::Owner -bor
        [int][System.Security.AccessControl.AccessControlSections]::Group -bor
        [int][System.Security.AccessControl.AccessControlSections]::Access
    )
    try {
        $security = $file.GetAccessControl($sections)
        [byte[]]$descriptor = $security.GetSecurityDescriptorBinaryForm()
    }
    catch {
        throw "Could not read Owner/Group/DACL metadata for $fullPath`: $($_.Exception.Message)"
    }

    return [pscustomobject]@{
        attributes = [int]$file.Attributes
        creation_time_utc_ticks = [long]$file.CreationTimeUtc.Ticks
        last_write_time_utc_ticks = [long]$file.LastWriteTimeUtc.Ticks
        last_access_time_utc_ticks = [long]$file.LastAccessTimeUtc.Ticks
        security_descriptor_base64 = [System.Convert]::ToBase64String($descriptor)
        security_descriptor_sections = 'Owner,Group,DACL'
        sacl_captured = $false
    }
}

function Compare-BF4SecurityDescriptorSections {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [byte[]]$Left,

        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [byte[]]$Right
    )

    try {
        $leftRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($Left, 0)
        $rightRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($Right, 0)
    }
    catch {
        throw "Could not parse an Owner/Group/DACL security descriptor: $($_.Exception.Message)"
    }

    $leftOwner = if ($null -eq $leftRaw.Owner) { $null } else { $leftRaw.Owner.Value }
    $rightOwner = if ($null -eq $rightRaw.Owner) { $null } else { $rightRaw.Owner.Value }
    $leftGroup = if ($null -eq $leftRaw.Group) { $null } else { $leftRaw.Group.Value }
    $rightGroup = if ($null -eq $rightRaw.Group) { $null } else { $rightRaw.Group.Value }
    $ownerEqual = ($leftOwner -ceq $rightOwner)
    $groupEqual = ($leftGroup -ceq $rightGroup)

    $ignoredFlags = [System.Security.AccessControl.ControlFlags]::DiscretionaryAclAutoInherited
    $leftRelevantFlags = [System.Security.AccessControl.ControlFlags](
        [int]$leftRaw.ControlFlags -band (-bnot [int]$ignoredFlags)
    )
    $rightRelevantFlags = [System.Security.AccessControl.ControlFlags](
        [int]$rightRaw.ControlFlags -band (-bnot [int]$ignoredFlags)
    )
    $accessEqual = ($leftRelevantFlags -eq $rightRelevantFlags)
    if ($accessEqual -and
        (($null -eq $leftRaw.DiscretionaryAcl) -ne ($null -eq $rightRaw.DiscretionaryAcl))) {
        $accessEqual = $false
    }
    if ($accessEqual -and $null -ne $leftRaw.DiscretionaryAcl) {
        [byte[]]$leftDacl = New-Object byte[] $leftRaw.DiscretionaryAcl.BinaryLength
        [byte[]]$rightDacl = New-Object byte[] $rightRaw.DiscretionaryAcl.BinaryLength
        $leftRaw.DiscretionaryAcl.GetBinaryForm($leftDacl, 0)
        $rightRaw.DiscretionaryAcl.GetBinaryForm($rightDacl, 0)
        $accessEqual = Test-BF4ByteArrayEqual -Left $leftDacl -Right $rightDacl
    }

    return [pscustomobject]@{
        OwnerEqual = [bool]$ownerEqual
        GroupEqual = [bool]$groupEqual
        AccessEqual = [bool]$accessEqual
        Equivalent = [bool]($ownerEqual -and $groupEqual -and $accessEqual)
    }
}

function Test-BF4SecurityDescriptorEquivalent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [byte[]]$Left,

        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [byte[]]$Right
    )

    $comparison = Compare-BF4SecurityDescriptorSections -Left $Left -Right $Right
    return [bool]($comparison.Equivalent)
}

function Set-BF4FileMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [object]$Metadata
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not [System.IO.File]::Exists($fullPath)) {
        throw "Metadata target file does not exist: $fullPath"
    }
    [uint64]$attributesWide = Convert-BF4UInt64 -Value (
        Get-BF4RequiredProperty -InputObject $Metadata -Name 'attributes'
    ) -Label 'file attributes'
    if ($attributesWide -gt [uint64][uint32]::MaxValue) {
        throw 'File attributes are outside UInt32 range.'
    }
    [System.IO.FileAttributes]$attributes = [uint32]$attributesWide
    if (($attributes -band [System.IO.FileAttributes]::Directory) -ne 0) {
        throw 'Directory attributes cannot be applied to a file.'
    }
    $creationUtc = Get-BF4MetadataDateTimeUtc -Ticks (
        Get-BF4RequiredProperty -InputObject $Metadata -Name 'creation_time_utc_ticks'
    ) -Label 'creation_time_utc_ticks'
    $lastWriteUtc = Get-BF4MetadataDateTimeUtc -Ticks (
        Get-BF4RequiredProperty -InputObject $Metadata -Name 'last_write_time_utc_ticks'
    ) -Label 'last_write_time_utc_ticks'
    $lastAccessUtc = Get-BF4MetadataDateTimeUtc -Ticks (
        Get-BF4RequiredProperty -InputObject $Metadata -Name 'last_access_time_utc_ticks'
    ) -Label 'last_access_time_utc_ticks'

    $descriptorText = [string](
        Get-BF4RequiredProperty -InputObject $Metadata -Name 'security_descriptor_base64'
    )
    try {
        [byte[]]$descriptor = [System.Convert]::FromBase64String($descriptorText)
    }
    catch {
        throw "security_descriptor_base64 is invalid: $($_.Exception.Message)"
    }
    if ($descriptor.Length -eq 0) {
        throw 'security_descriptor_base64 decodes to an empty descriptor.'
    }

    try {
        $currentAttributes = [System.IO.File]::GetAttributes($fullPath)
        if (($currentAttributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
            [System.IO.File]::SetAttributes(
                $fullPath,
                ($currentAttributes -band (-bnot [System.IO.FileAttributes]::ReadOnly))
            )
        }
        [System.IO.File]::SetCreationTimeUtc($fullPath, $creationUtc)
        [System.IO.File]::SetLastWriteTimeUtc($fullPath, $lastWriteUtc)
        [System.IO.File]::SetLastAccessTimeUtc($fullPath, $lastAccessUtc)
        [System.IO.File]::SetAttributes($fullPath, $attributes)
    }
    catch {
        throw "Could not restore timestamps/attributes for $fullPath`: $($_.Exception.Message)"
    }

    $sections = [System.Security.AccessControl.AccessControlSections](
        [int][System.Security.AccessControl.AccessControlSections]::Owner -bor
        [int][System.Security.AccessControl.AccessControlSections]::Group -bor
        [int][System.Security.AccessControl.AccessControlSections]::Access
    )
    try {
        $security = New-Object System.Security.AccessControl.FileSecurity
        $security.SetSecurityDescriptorBinaryForm($descriptor, $sections)
        $file = New-Object System.IO.FileInfo($fullPath)
        $currentSecurity = $file.GetAccessControl($sections)
        [byte[]]$currentDescriptor = $currentSecurity.GetSecurityDescriptorBinaryForm()
        [byte[]]$expectedDescriptor = $security.GetSecurityDescriptorBinaryForm()
        $comparison = Compare-BF4SecurityDescriptorSections -Left $currentDescriptor -Right $expectedDescriptor
        if (-not $comparison.Equivalent) {
            $sectionsToRestoreValue = 0
            if (-not $comparison.OwnerEqual) {
                $sectionsToRestoreValue = $sectionsToRestoreValue -bor [int][System.Security.AccessControl.AccessControlSections]::Owner
            }
            if (-not $comparison.GroupEqual) {
                $sectionsToRestoreValue = $sectionsToRestoreValue -bor [int][System.Security.AccessControl.AccessControlSections]::Group
            }
            if (-not $comparison.AccessEqual) {
                $sectionsToRestoreValue = $sectionsToRestoreValue -bor [int][System.Security.AccessControl.AccessControlSections]::Access
            }
            $sectionsToRestore = [System.Security.AccessControl.AccessControlSections]$sectionsToRestoreValue
            $restoreSecurity = New-Object System.Security.AccessControl.FileSecurity
            $restoreSecurity.SetSecurityDescriptorBinaryForm($descriptor, $sectionsToRestore)
            $file.SetAccessControl($restoreSecurity)
            $currentSecurity = $file.GetAccessControl($sections)
            [byte[]]$currentDescriptor = $currentSecurity.GetSecurityDescriptorBinaryForm()
            if (-not (Test-BF4SecurityDescriptorEquivalent -Left $currentDescriptor -Right $expectedDescriptor)) {
                throw 'Owner/Group/DACL verification failed after restoration.'
            }
        }
    }
    catch {
        throw "Could not restore Owner/Group/DACL metadata for $fullPath`: $($_.Exception.Message)"
    }

}

function Enable-BF4TemporaryAtomicReplaceAccess {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not [System.IO.File]::Exists($fullPath)) {
        throw "Atomic-replace access target does not exist: $fullPath"
    }

    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $tokenSids = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    [void]$tokenSids.Add($identity.User.Value)
    foreach ($group in $identity.Groups) {
        [void]$tokenSids.Add($group.Value)
    }

    [System.Security.AccessControl.FileSystemRights]$blockingRights = (
        [System.Security.AccessControl.FileSystemRights]::Delete -bor
        [System.Security.AccessControl.FileSystemRights]::WriteData -bor
        [System.Security.AccessControl.FileSystemRights]::AppendData -bor
        [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles
    )
    $file = New-Object System.IO.FileInfo($fullPath)
    try {
        $security = $file.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
        $rules = @($security.GetAccessRules($true, $false, [System.Security.Principal.SecurityIdentifier]))
        $removed = 0
        foreach ($rule in $rules) {
            if ($rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Deny) { continue }
            if (-not $tokenSids.Contains($rule.IdentityReference.Value)) { continue }
            if (($rule.FileSystemRights -band $blockingRights) -eq 0) { continue }
            $security.RemoveAccessRuleSpecific($rule)
            $removed++
        }
        if ($removed -gt 0) {
            $file.SetAccessControl($security)
        }
        return [int]$removed
    }
    catch {
        throw "Could not temporarily permit atomic replacement for $fullPath`: $($_.Exception.Message)"
    }
}

function New-BF4SiblingStageFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$TargetPath,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [byte[]]$Bytes
    )

    $targetFull = [System.IO.Path]::GetFullPath($TargetPath)
    $directory = [System.IO.Path]::GetDirectoryName($targetFull)
    $leaf = [System.IO.Path]::GetFileName($targetFull)
    if ([string]::IsNullOrEmpty($directory) -or [string]::IsNullOrEmpty($leaf)) {
        throw "Target path does not identify a file: $TargetPath"
    }
    if (-not [System.IO.Directory]::Exists($directory)) {
        throw "Staging directory does not exist: $directory"
    }

    for ($attempt = 0; $attempt -lt 32; $attempt++) {
        $stageName = ".$leaf.bf4patch.$([System.Guid]::NewGuid().ToString('N')).stage"
        $stagePath = [System.IO.Path]::Combine($directory, $stageName)
        $stream = $null
        $createdStage = $false
        try {
            $stream = [System.IO.File]::Open(
                $stagePath,
                [System.IO.FileMode]::CreateNew,
                [System.IO.FileAccess]::Write,
                [System.IO.FileShare]::None
            )
            $createdStage = $true
            $stream.Write($Bytes, 0, $Bytes.Length)
            $stream.Flush($true)
            $stream.Dispose()
            $stream = $null
            if ((Get-BF4Sha256Hex -Path $stagePath) -ne (Get-BF4Sha256Hex -Bytes $Bytes)) {
                throw "Staged bytes changed after writing: $stagePath"
            }
            return $stagePath
        }
        catch [System.IO.IOException] {
            if ($null -ne $stream) {
                $stream.Dispose()
            }
            if ($createdStage -and [System.IO.File]::Exists($stagePath)) {
                [System.IO.File]::Delete($stagePath)
            }
            if ($attempt -eq 31) {
                throw
            }
        }
        catch {
            if ($null -ne $stream) {
                $stream.Dispose()
            }
            if ($createdStage -and [System.IO.File]::Exists($stagePath)) {
                [System.IO.File]::Delete($stagePath)
            }
            throw
        }
    }
    throw 'Could not allocate a sibling staging file.'
}

function Invoke-BF4AtomicReplace {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$StagedPath,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$TargetPath,

        [AllowNull()]
        [string]$BackupPath = $null
    )

    $stageFull = [System.IO.Path]::GetFullPath($StagedPath)
    $targetFull = [System.IO.Path]::GetFullPath($TargetPath)
    if (-not [System.IO.File]::Exists($stageFull)) {
        throw "Staging file does not exist: $stageFull"
    }
    if (-not [System.IO.File]::Exists($targetFull)) {
        throw "Atomic replacement target does not exist: $targetFull"
    }
    $stageDirectory = [System.IO.Path]::GetDirectoryName($stageFull).TrimEnd([char]'\', [char]'/')
    $targetDirectory = [System.IO.Path]::GetDirectoryName($targetFull).TrimEnd([char]'\', [char]'/')
    if (-not $stageDirectory.Equals($targetDirectory, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Staging file must be in the target file directory.'
    }
    if ($stageFull.Equals($targetFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Staging and target paths must differ.'
    }
    if (([System.IO.File]::GetAttributes($stageFull) -band [System.IO.FileAttributes]::ReparsePoint) -ne 0 -or
        ([System.IO.File]::GetAttributes($targetFull) -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'Atomic replacement does not accept reparse-point files.'
    }

    $backupFull = $null
    $removeEphemeralBackup = $false
    if (-not [string]::IsNullOrWhiteSpace($BackupPath)) {
        $backupFull = [System.IO.Path]::GetFullPath($BackupPath)
        if ($backupFull.Equals($stageFull, [System.StringComparison]::OrdinalIgnoreCase) -or
            $backupFull.Equals($targetFull, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'Atomic replacement backup path collides with a source path.'
        }
        if ([System.IO.File]::Exists($backupFull) -or [System.IO.Directory]::Exists($backupFull)) {
            throw "Atomic replacement backup path already exists: $backupFull"
        }
        $backupDirectory = [System.IO.Path]::GetDirectoryName($backupFull)
        if (-not [System.IO.Directory]::Exists($backupDirectory)) {
            throw "Atomic replacement backup directory does not exist: $backupDirectory"
        }
    }
    else {
        for ($attempt = 0; $attempt -lt 32; $attempt++) {
            $backupLeaf = '.' + [System.IO.Path]::GetFileName($targetFull) + '.bf4patch.' +
                [System.Guid]::NewGuid().ToString('N') + '.replaced'
            $backupFull = [System.IO.Path]::Combine($targetDirectory, $backupLeaf)
            if (-not [System.IO.File]::Exists($backupFull) -and -not [System.IO.Directory]::Exists($backupFull)) {
                break
            }
            $backupFull = $null
        }
        if ($null -eq $backupFull) {
            throw 'Could not allocate an atomic replacement backup path.'
        }
        $removeEphemeralBackup = $true
    }

    [System.IO.File]::Replace($stageFull, $targetFull, $backupFull, $false)
    if (-not [System.IO.File]::Exists($targetFull) -or [System.IO.File]::Exists($stageFull)) {
        throw 'Atomic replacement did not reach its expected final state.'
    }
    if ($removeEphemeralBackup) {
        [System.IO.File]::Delete($backupFull)
        if ([System.IO.File]::Exists($backupFull)) {
            throw "Atomic replacement temporary backup could not be removed: $backupFull"
        }
    }
    return $targetFull
}

function Write-BF4DurableJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [object]$Value,

        [ValidateRange(2, 100)]
        [int]$Depth = 32,

        [switch]$Compress
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $directory = [System.IO.Path]::GetDirectoryName($fullPath)
    if (-not [System.IO.Directory]::Exists($directory)) {
        throw "Durable JSON directory does not exist: $directory"
    }
    if ([System.IO.Directory]::Exists($fullPath)) {
        throw "Durable JSON target is a directory: $fullPath"
    }
    try {
        $json = ConvertTo-Json -InputObject $Value -Depth $Depth -Compress:$Compress -ErrorAction Stop
        [void](ConvertFrom-Json -InputObject $json -ErrorAction Stop)
    }
    catch {
        throw "Could not serialize durable JSON: $($_.Exception.Message)"
    }
    $json += "`n"
    $utf8Bom = New-Object System.Text.UTF8Encoding($true, $true)
    [byte[]]$preamble = $utf8Bom.GetPreamble()
    [byte[]]$content = $utf8Bom.GetBytes($json)
    [byte[]]$payload = New-Object byte[] ($preamble.Length + $content.Length)
    [System.Array]::Copy($preamble, 0, $payload, 0, $preamble.Length)
    [System.Array]::Copy($content, 0, $payload, $preamble.Length, $content.Length)

    $stagePath = $null
    try {
        $stagePath = New-BF4SiblingStageFile -TargetPath $fullPath -Bytes $payload
        if ([System.IO.File]::Exists($fullPath)) {
            [void](Invoke-BF4AtomicReplace -StagedPath $stagePath -TargetPath $fullPath)
            $stagePath = $null
        }
        else {
            [System.IO.File]::Move($stagePath, $fullPath)
            $stagePath = $null
        }
        [byte[]]$reread = [System.IO.File]::ReadAllBytes($fullPath)
        if (-not (Test-BF4ByteArrayEqual -Left $reread -Right $payload)) {
            throw "Durable JSON bytes changed after writing: $fullPath"
        }
        return $fullPath
    }
    finally {
        if ($null -ne $stagePath -and [System.IO.File]::Exists($stagePath)) {
            [System.IO.File]::Delete($stagePath)
        }
    }
}

function Test-BF4PatchCore {
    [CmdletBinding()]
    param()

    $checks = New-Object 'System.Collections.Generic.List[string]'

    function Assert-CoreTest {
        param(
            [bool]$Condition,
            [string]$Message
        )
        if (-not $Condition) {
            throw "BF4Patch.Core self-test failed: $Message"
        }
    }

    function Assert-CoreThrows {
        param(
            [scriptblock]$Action,
            [string]$Message
        )
        $didThrow = $false
        try {
            & $Action
        }
        catch {
            $didThrow = $true
        }
        if (-not $didThrow) {
            throw "BF4Patch.Core self-test failed: expected rejection for $Message"
        }
    }

    function New-CoreTestDelta {
        param(
            [byte[]]$Source,
            [byte[]]$Target,
            [byte[]]$Body,
            [byte[]]$EncodedBody,
            [uint16]$Flags,
            [uint64]$CommandCount
        )
        $stream = New-Object System.IO.MemoryStream
        $writer = New-Object System.IO.BinaryWriter($stream)
        try {
            $writer.Write([System.Text.Encoding]::ASCII.GetBytes("BF4DXR1`0"))
            $writer.Write([uint16]1)
            $writer.Write($Flags)
            $writer.Write([uint32]152)
            $writer.Write([uint64]$Source.LongLength)
            $writer.Write([uint64]$Target.LongLength)
            $writer.Write((Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $Source) -ExpectedByteCount 32))
            $writer.Write((Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $Target) -ExpectedByteCount 32))
            $writer.Write((Convert-BF4HexToBytes -Hex (Get-BF4Sha256Hex -Bytes $Body) -ExpectedByteCount 32))
            $writer.Write($CommandCount)
            $writer.Write([uint64]$Body.LongLength)
            $writer.Write([uint64]$EncodedBody.LongLength)
            $writer.Write($EncodedBody)
            $writer.Flush()
            [byte[]]$result = $stream.ToArray()
            return ,$result
        }
        finally {
            $writer.Dispose()
            $stream.Dispose()
        }
    }

    $abc = [System.Text.Encoding]::ASCII.GetBytes('abc')
    Assert-CoreTest -Condition (
        (Get-BF4Sha256Hex -Bytes $abc) -eq 'BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD'
    ) -Message 'SHA-256 vector'
    [void]$checks.Add('sha256')

    $crcVector = [System.Text.Encoding]::ASCII.GetBytes('123456789')
    $crcHex = '{0:X8}' -f (Get-BF4Crc32Bzip2 -Bytes $crcVector)
    Assert-CoreTest -Condition ($crcHex -eq 'FC891918') -Message 'CRC32-BZIP2 check vector'
    [void]$checks.Add('crc32-bzip2')

    $safe = Assert-BF4SafeRelativePath -Path 'assets/folder name/file.json'
    Assert-CoreTest -Condition ($safe -eq 'assets\folder name\file.json') -Message 'safe relative path normalization'
    Assert-CoreThrows -Action { Assert-BF4SafeRelativePath -Path '../escape.bin' } -Message 'relative traversal'
    Assert-CoreThrows -Action { Assert-BF4SafeRelativePath -Path 'C:\escape.bin' } -Message 'rooted path'
    Assert-CoreThrows -Action { Assert-BF4SafeRelativePath -Path 'assets\CON.txt' } -Message 'reserved device path'
    $containedRoot = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), 'bf4-contained-root')
    $contained = Resolve-BF4ContainedPath -Root $containedRoot -RelativePath 'a/b.bin'
    Assert-CoreTest -Condition (
        $contained.StartsWith(
            [System.IO.Path]::GetFullPath($containedRoot).TrimEnd([char]'\') + '\',
            [System.StringComparison]::OrdinalIgnoreCase
        )
    ) -Message 'contained path'
    [void]$checks.Add('safe-paths')

    $versionsStream = New-Object System.IO.MemoryStream
    $versionsWriter = New-Object System.IO.BinaryWriter($versionsStream)
    try {
        foreach ($entry in @(
            [pscustomobject]@{ Crc = [uint32]1; Path = 'assets/a.json' },
            [pscustomobject]@{ Crc = [uint32]2; Path = 'assets/b.json' }
        )) {
            [byte[]]$pathBytes = [System.Text.Encoding]::ASCII.GetBytes($entry.Path)
            $versionsWriter.Write([uint32]$entry.Crc)
            $versionsWriter.Write([uint32]$pathBytes.Length)
            $versionsWriter.Write($pathBytes)
        }
        $versionsWriter.Flush()
        [byte[]]$versionsBytes = $versionsStream.ToArray()
    }
    finally {
        $versionsWriter.Dispose()
        $versionsStream.Dispose()
    }
    $versionUpdates = @(
        [pscustomobject]@{
            path = 'assets/a.json'
            expected_crc32_bzip2 = '00000001'
            target_crc32_bzip2 = '11223344'
        },
        [pscustomobject]@{
            path = 'assets/b.json'
            expected_crc32_bzip2 = '00000002'
            target_crc32_bzip2 = 'AABBCCDD'
        }
    )
    [byte[]]$updatedVersions = Update-BF4VersionsCrcBytes -Bytes $versionsBytes -Updates $versionUpdates
    $updatedRecords = @(Read-BF4VersionsBytes -Bytes $updatedVersions)
    Assert-CoreTest -Condition (
        $updatedRecords.Count -eq 2 -and
        $updatedRecords[0].StoredCrc32Bzip2Hex -eq '11223344' -and
        $updatedRecords[1].StoredCrc32Bzip2Hex -eq 'AABBCCDD' -and
        $updatedVersions.Length -eq $versionsBytes.Length
    ) -Message 'strict versions CRC replacement'
    [byte[]]$truncatedVersions = New-Object byte[] ($versionsBytes.Length - 1)
    [System.Array]::Copy($versionsBytes, $truncatedVersions, $truncatedVersions.Length)
    Assert-CoreThrows -Action { Read-BF4VersionsBytes -Bytes $truncatedVersions } -Message 'truncated versions'
    [void]$checks.Add('versions')

    $jsonSourceText = '{"A":"x","B":"same"}'
    $jsonTargetText = '{"A":"z","B":"same"}  '
    [byte[]]$jsonSource = [System.Text.Encoding]::UTF8.GetBytes($jsonSourceText)
    [byte[]]$jsonTarget = [System.Text.Encoding]::UTF8.GetBytes($jsonTargetText)
    [int]$tokenOffset = $jsonSourceText.IndexOf('"x"', [System.StringComparison]::Ordinal)
    [byte[]]$sourceToken = [System.Text.Encoding]::UTF8.GetBytes('"x"')
    $jsonPatch = [pscustomobject]@{
        path = 'assets/test.json'
        source_size = $jsonSource.Length
        source_sha256 = Get-BF4Sha256Hex -Bytes $jsonSource
        target_size = $jsonTarget.Length
        target_sha256 = Get-BF4Sha256Hex -Bytes $jsonTarget
        key_count = 2
        change_count = 1
        append_ascii_space_count = 2
        changes = @(
            [pscustomobject]@{
                key = 'A'
                source_value_token_byte_offset = $tokenOffset
                source_value_token_byte_length = $sourceToken.Length
                source_value_token_sha256 = Get-BF4Sha256Hex -Bytes $sourceToken
                target_json_string_token = '"z"'
            }
        )
    }
    [byte[]]$jsonActual = Apply-BF4JsonPatchBytes -SourceBytes $jsonSource -FilePatch $jsonPatch
    Assert-CoreTest -Condition (
        Test-BF4ByteArrayEqual -Left $jsonActual -Right $jsonTarget
    ) -Message 'byte-exact JSON key patch'
    [byte[]]$wrongJsonSource = [System.Text.Encoding]::UTF8.GetBytes('{"A":"q","B":"same"}')
    Assert-CoreThrows -Action {
        Apply-BF4JsonPatchBytes -SourceBytes $wrongJsonSource -FilePatch $jsonPatch
    } -Message 'JSON source hash gate'
    [void]$checks.Add('json-patch')

    [byte[]]$deltaSource = [System.Text.Encoding]::ASCII.GetBytes('abcdef')
    [byte[]]$deltaTarget = [System.Text.Encoding]::ASCII.GetBytes('abcXYDEF')
    [byte[]]$deltaBody = [byte[]]@(
        1, 0, 3,
        2, 2, 88, 89,
        3, 3, 3, 32, 32, 32,
        0
    )
    [byte[]]$plainDelta = New-CoreTestDelta -Source $deltaSource -Target $deltaTarget -Body $deltaBody -EncodedBody $deltaBody -Flags 0 -CommandCount 3
    [byte[]]$plainDeltaActual = Apply-BF4DeltaBytes -SourceBytes $deltaSource -PatchBytes $plainDelta
    Assert-CoreTest -Condition (
        Test-BF4ByteArrayEqual -Left $plainDeltaActual -Right $deltaTarget
    ) -Message 'COPY/ADD/XOR_FROM_SOURCE delta'

    $compressedStream = New-Object System.IO.MemoryStream
    $deflater = New-Object System.IO.Compression.DeflateStream(
        $compressedStream,
        [System.IO.Compression.CompressionMode]::Compress,
        $true
    )
    try {
        $deflater.Write($deltaBody, 0, $deltaBody.Length)
        $deflater.Dispose()
        $deflater = $null
        [byte[]]$compressedBody = $compressedStream.ToArray()
    }
    finally {
        if ($null -ne $deflater) {
            $deflater.Dispose()
        }
        $compressedStream.Dispose()
    }
    [byte[]]$compressedDelta = New-CoreTestDelta -Source $deltaSource -Target $deltaTarget -Body $deltaBody -EncodedBody $compressedBody -Flags 1 -CommandCount 3
    [byte[]]$compressedDeltaActual = Apply-BF4DeltaBytes -SourceBytes $deltaSource -PatchBytes $compressedDelta
    Assert-CoreTest -Condition (
        Test-BF4ByteArrayEqual -Left $compressedDeltaActual -Right $deltaTarget
    ) -Message 'raw Deflate delta'
    [void]$checks.Add('bf4-delta')

    $tempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
    $testRoot = [System.IO.Path]::Combine(
        $tempBase,
        'bf4patch-core-selftest-' + [System.Guid]::NewGuid().ToString('N')
    )
    [void][System.IO.Directory]::CreateDirectory($testRoot)
    try {
        $targetPath = [System.IO.Path]::Combine($testRoot, 'target.bin')
        [System.IO.File]::WriteAllBytes($targetPath, [System.Text.Encoding]::ASCII.GetBytes('old'))
        $metadata = Get-BF4FileMetadata -Path $targetPath
        [System.IO.File]::SetLastWriteTimeUtc($targetPath, [System.DateTime]::UtcNow.AddHours(-2))
        Set-BF4FileMetadata -Path $targetPath -Metadata $metadata
        $restoredMetadata = Get-BF4FileMetadata -Path $targetPath
        Assert-CoreTest -Condition (
            $restoredMetadata.attributes -eq $metadata.attributes -and
            $restoredMetadata.creation_time_utc_ticks -eq $metadata.creation_time_utc_ticks -and
            $restoredMetadata.last_write_time_utc_ticks -eq $metadata.last_write_time_utc_ticks -and
            $restoredMetadata.last_access_time_utc_ticks -eq $metadata.last_access_time_utc_ticks -and
            $restoredMetadata.security_descriptor_base64 -eq $metadata.security_descriptor_base64 -and
            $restoredMetadata.sacl_captured -eq $false
        ) -Message 'file metadata Owner/Group/DACL and timestamps'
        [void]$checks.Add('file-metadata')

        [byte[]]$metadataDescriptor = [System.Convert]::FromBase64String(
            [string]$metadata.security_descriptor_base64
        )
        $metadataRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($metadataDescriptor, 0)
        $metadataSections = [System.Security.AccessControl.AccessControlSections](
            [int][System.Security.AccessControl.AccessControlSections]::Owner -bor
            [int][System.Security.AccessControl.AccessControlSections]::Group -bor
            [int][System.Security.AccessControl.AccessControlSections]::Access
        )
        $metadataSddl = $metadataRaw.GetSddlForm($metadataSections)
        if ($metadataSddl -match 'D:AI') {
            $equivalentSddl = $metadataSddl -replace 'D:AI', 'D:'
        }
        else {
            $equivalentSddl = $metadataSddl -replace 'D:', 'D:AI'
        }
        $equivalentRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($equivalentSddl)
        [byte[]]$equivalentDescriptor = New-Object byte[] $equivalentRaw.BinaryLength
        $equivalentRaw.GetBinaryForm($equivalentDescriptor, 0)
        Assert-CoreTest -Condition (
            Test-BF4SecurityDescriptorEquivalent -Left $metadataDescriptor -Right $equivalentDescriptor
        ) -Message 'DACL auto-inherited control flag equivalence'

        $protectedSddl = $metadataSddl -replace 'D:(AI)?', 'D:P'
        $protectedRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($protectedSddl)
        [byte[]]$protectedDescriptor = New-Object byte[] $protectedRaw.BinaryLength
        $protectedRaw.GetBinaryForm($protectedDescriptor, 0)
        Assert-CoreTest -Condition (-not (
            Test-BF4SecurityDescriptorEquivalent -Left $metadataDescriptor -Right $protectedDescriptor
        )) -Message 'DACL protection difference detection'

        $requiredSddl = $metadataSddl -replace 'D:(AI)?', 'D:AR'
        $requiredRaw = New-Object System.Security.AccessControl.RawSecurityDescriptor($requiredSddl)
        [byte[]]$requiredDescriptor = New-Object byte[] $requiredRaw.BinaryLength
        $requiredRaw.GetBinaryForm($requiredDescriptor, 0)
        Assert-CoreTest -Condition (-not (
            Test-BF4SecurityDescriptorEquivalent -Left $metadataDescriptor -Right $requiredDescriptor
        )) -Message 'non-AI control flag difference detection'

        $equivalentMetadata = [pscustomobject]@{
            attributes = $metadata.attributes
            creation_time_utc_ticks = $metadata.creation_time_utc_ticks
            last_write_time_utc_ticks = $metadata.last_write_time_utc_ticks
            last_access_time_utc_ticks = $metadata.last_access_time_utc_ticks
            security_descriptor_base64 = [System.Convert]::ToBase64String($equivalentDescriptor)
            security_descriptor_sections = 'Owner,Group,DACL'
            sacl_captured = $false
        }
        Set-BF4FileMetadata -Path $targetPath -Metadata $equivalentMetadata
        $afterEquivalentSet = Get-BF4FileMetadata -Path $targetPath
        Assert-CoreTest -Condition (
            Test-BF4SecurityDescriptorEquivalent -Left (
                [System.Convert]::FromBase64String([string]$afterEquivalentSet.security_descriptor_base64)
            ) -Right $equivalentDescriptor
        ) -Message 'equivalent ACL no-op metadata restoration'
        [void]$checks.Add('acl-equivalent-no-op')

        [byte[]]$newBytes = [System.Text.Encoding]::ASCII.GetBytes('new')
        [byte[]]$aclBeforeReplace = [System.Convert]::FromBase64String(
            [string]$afterEquivalentSet.security_descriptor_base64
        )
        $stagePath = New-BF4SiblingStageFile -TargetPath $targetPath -Bytes $newBytes
        [void](Invoke-BF4AtomicReplace -StagedPath $stagePath -TargetPath $targetPath)
        [byte[]]$atomicBytes = [System.IO.File]::ReadAllBytes($targetPath)
        $metadataAfterReplace = Get-BF4FileMetadata -Path $targetPath
        [byte[]]$aclAfterReplace = [System.Convert]::FromBase64String(
            [string]$metadataAfterReplace.security_descriptor_base64
        )
        Assert-CoreTest -Condition (
            (Test-BF4ByteArrayEqual -Left $atomicBytes -Right $newBytes) -and
            -not [System.IO.File]::Exists($stagePath) -and
            (Test-BF4SecurityDescriptorEquivalent -Left $aclBeforeReplace -Right $aclAfterReplace)
        ) -Message 'same-directory File.Replace'
        [void]$checks.Add('atomic-replace')
        [void]$checks.Add('file-replace-acl')

        $denyTargetPath = [System.IO.Path]::Combine($testRoot, 'deny-target.bin')
        [System.IO.File]::WriteAllBytes($denyTargetPath, [System.Text.Encoding]::ASCII.GetBytes('deny-old'))
        $denyFile = New-Object System.IO.FileInfo($denyTargetPath)
        $denySid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
        [System.Security.AccessControl.FileSystemRights]$denyRights = (
            [System.Security.AccessControl.FileSystemRights]::Delete -bor
            [System.Security.AccessControl.FileSystemRights]::WriteData -bor
            [System.Security.AccessControl.FileSystemRights]::AppendData -bor
            [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor
            [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
            [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles
        )
        try {
            $denySecurity = $denyFile.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
            $denyRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                $denySid,
                $denyRights,
                [System.Security.AccessControl.AccessControlType]::Deny
            )
            $denySecurity.AddAccessRule($denyRule)
            $denyFile.SetAccessControl($denySecurity)
            $denyMetadata = Get-BF4FileMetadata -Path $denyTargetPath
            $removedDenyCount = Enable-BF4TemporaryAtomicReplaceAccess -Path $denyTargetPath
            $denyStagePath = New-BF4SiblingStageFile -TargetPath $denyTargetPath -Bytes (
                [System.Text.Encoding]::ASCII.GetBytes('deny-new')
            )
            [void](Invoke-BF4AtomicReplace -StagedPath $denyStagePath -TargetPath $denyTargetPath)
            Set-BF4FileMetadata -Path $denyTargetPath -Metadata $denyMetadata
            $denyRestored = Get-BF4FileMetadata -Path $denyTargetPath
            Assert-CoreTest -Condition (
                $removedDenyCount -gt 0 -and
                [System.Text.Encoding]::ASCII.GetString([System.IO.File]::ReadAllBytes($denyTargetPath)) -ceq 'deny-new' -and
                $denyRestored.creation_time_utc_ticks -eq $denyMetadata.creation_time_utc_ticks -and
                $denyRestored.last_write_time_utc_ticks -eq $denyMetadata.last_write_time_utc_ticks -and
                (Test-BF4SecurityDescriptorEquivalent -Left (
                    [System.Convert]::FromBase64String([string]$denyRestored.security_descriptor_base64)
                ) -Right (
                    [System.Convert]::FromBase64String([string]$denyMetadata.security_descriptor_base64)
                ))
            ) -Message 'temporary explicit deny relaxation and metadata restoration'
            [void]$checks.Add('temporary-deny-atomic-replace')
        }
        finally {
            if ([System.IO.File]::Exists($denyTargetPath)) {
                $cleanupFile = New-Object System.IO.FileInfo($denyTargetPath)
                $cleanupSecurity = $cleanupFile.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
                foreach ($cleanupRule in @($cleanupSecurity.GetAccessRules($true, $false, [System.Security.Principal.SecurityIdentifier]))) {
                    if ($cleanupRule.IdentityReference.Value -eq $denySid.Value -and
                        $cleanupRule.AccessControlType -eq [System.Security.AccessControl.AccessControlType]::Deny -and
                        ($cleanupRule.FileSystemRights -band $denyRights) -ne 0) {
                        $cleanupSecurity.RemoveAccessRuleSpecific($cleanupRule)
                    }
                }
                $cleanupFile.SetAccessControl($cleanupSecurity)
            }
        }

        $jsonPath = [System.IO.Path]::Combine($testRoot, 'durable.json')
        [void](Write-BF4DurableJson -Path $jsonPath -Value ([ordered]@{ state = 'first'; count = 1 }) -Compress)
        [void](Write-BF4DurableJson -Path $jsonPath -Value ([ordered]@{ state = 'second'; count = 2 }) -Compress)
        [byte[]]$durableBytes = [System.IO.File]::ReadAllBytes($jsonPath)
        Assert-CoreTest -Condition (
            $durableBytes.Length -ge 4 -and
            $durableBytes[0] -eq 239 -and
            $durableBytes[1] -eq 187 -and
            $durableBytes[2] -eq 191
        ) -Message 'durable JSON UTF-8 BOM'
        $durableText = [System.Text.Encoding]::UTF8.GetString($durableBytes, 3, $durableBytes.Length - 3)
        $durableObject = ConvertFrom-Json -InputObject $durableText -ErrorAction Stop
        Assert-CoreTest -Condition (
            $durableObject.state -eq 'second' -and [int]$durableObject.count -eq 2
        ) -Message 'durable JSON atomic rewrite'
        [void]$checks.Add('durable-json')
    }
    finally {
        $testRootFull = [System.IO.Path]::GetFullPath($testRoot)
        $safePrefix = $tempBase.TrimEnd([char]'\', [char]'/') + [System.IO.Path]::DirectorySeparatorChar + 'bf4patch-core-selftest-'
        if (-not $testRootFull.StartsWith($safePrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'Self-test cleanup path failed its safety check.'
        }
        if ([System.IO.Directory]::Exists($testRootFull)) {
            [System.IO.Directory]::Delete($testRootFull, $true)
        }
    }

    return [pscustomobject]@{
        Passed = $true
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        CheckCount = $checks.Count
        Checks = $checks.ToArray()
    }
}
