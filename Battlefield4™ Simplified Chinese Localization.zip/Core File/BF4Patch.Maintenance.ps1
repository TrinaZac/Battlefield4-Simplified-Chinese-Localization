﻿# Check is read-only. Repair reuses verified original backups and journals only
# the changed subset; it never replaces the install/uninstall recovery state.

function Get-RepairJournalPath {
    param([object]$Context)
    return [IO.Path]::Combine($Context.StateInstanceRoot, 'repair-current.json')
}

function Read-RepairJournal {
    param([object]$Context)
    $path = Get-RepairJournalPath $Context
    if (-not [IO.File]::Exists($path)) { return $null }
    Assert-RegularTargetFile $path
    $journal = Read-JsonFile $path
    if ($journal.status -notin @('planned','prepared','committing','rolling_back','rollback_failed','repaired','rolled_back')) { throw 'Unknown repair journal status.' }
    return $journal
}

function Assert-NoPendingRepair {
    param([object]$Context, [switch]$AllowPending)
    $journal = Read-RepairJournal $Context
    if ($null -ne $journal -and $journal.status -notin @('repaired','rolled_back') -and -not $AllowPending) {
        throw 'A repair transaction needs recovery. Close BF4 and run Repair.cmd from this package with the same StateRoot.'
    }
}

function Assert-RepairOriginals {
    param([object]$Manifest, [object]$Context)
    $state = $Context.ManagedState
    if ($null -eq $state -or $state.action -ne 'install' -or $state.status -ne 'installed' -or $state.mode -ne 'fresh') {
        throw 'Repair requires a completed normal installation and its original backups. Use Install.cmd for an uninstalled game; adopted or missing state cannot be repaired.'
    }
    foreach ($op in $state.operations) {
        if ($op.id -ne 'twinkle-versions') {
            $f = Get-ManifestFileById $Manifest $op.id
            if ($op.pre_sha256 -ne $f.source_sha256 -or $op.post_sha256 -ne $f.target_sha256) { throw 'Original installation hashes do not match this package.' }
        }
        $backup = Resolve-BF4ContainedPath $Context.StateInstanceRoot $op.backup_relative
        Assert-RegularTargetFile $backup
        if ((Get-BF4Sha256Hex -Path $backup) -ne $op.pre_sha256) { throw "Original recovery backup is invalid: $($op.id)" }
    }
    if ($Context.Classification -eq 'Unsupported') { throw 'Unknown resource bytes found. Repair refuses unsupported updates or other mods.' }
}

function Get-PatchedVersionsBytes {
    param([byte[]]$Bytes, [object]$Manifest)
    $records = @(Read-BF4VersionsBytes -Bytes $Bytes)
    $updates = @()
    foreach ($u in $Manifest.versions.updates) {
        $r = @($records | Where-Object { $_.NormalizedPath -eq (Get-NormalizedVersionsPath $u.path) })
        if ($r.Count -ne 1) { throw 'Managed versions record is missing or duplicated.' }
        $crc = $r[0].StoredCrc32Bzip2Hex
        if ($crc -ne $u.source_crc32_bzip2 -and $crc -ne $u.target_crc32_bzip2) { throw 'Unknown managed cache CRC; repair refused.' }
        if ($crc -ne $u.target_crc32_bzip2) {
            $updates += [pscustomobject]@{ path=$u.path; expected_crc32_bzip2=$crc; target_crc32_bzip2=$u.target_crc32_bzip2 }
        }
    }
    if ($updates.Count -eq 0) { return ,$Bytes.Clone() }
    return ,(Update-BF4VersionsCrcBytes -Bytes $Bytes -Updates $updates -ExpectedUpdateCount $updates.Count)
}

function Save-RepairJournal {
    param([object]$Journal, [object]$Context)
    Write-DurableJson (Resolve-BF4ContainedPath $Context.StateInstanceRoot ('repairs\'+$Journal.id+'\transaction.json')) $Journal
    Write-DurableJson (Get-RepairJournalPath $Context) $Journal
}

function Assert-RepairJournal {
    param([object]$Journal, [object]$Manifest, [object]$Context)
    if ($Journal.schema -ne 1 -or $Journal.id -notmatch '^repair-[0-9a-f]{32}$' -or
        $Journal.parent_transaction_id -ne $Context.ManagedState.transaction_id -or
        $Journal.game_root -ne $Context.GameRoot -or $Journal.twinkle_root -ne $Context.TwinkleRoot) { throw 'Repair journal binding mismatch.' }
    if (@($Journal.operations).Count -lt 1 -or @($Journal.operations).Count -gt 12) { throw 'Repair operation count is invalid.' }
    $seen = @{}
    foreach ($op in $Journal.operations) {
        if ($seen.ContainsKey([string]$op.id)) { throw 'Duplicate repair operation.' }; $seen[[string]$op.id]=$true
        if ($op.id -eq 'twinkle-versions') {
            if ($op.root -ne 'twinkle' -or $op.relative_path -ne $Manifest.versions.relative_path -or
                $op.backup_relative -ne ('repairs\'+$Journal.id+'\versions-before.bin')) { throw 'Unsafe versions repair operation.' }
            $backup = Resolve-BF4ContainedPath $Context.StateInstanceRoot $op.backup_relative
            if ([IO.File]::Exists($backup)) {
                Assert-RegularTargetFile $backup
                $bytes = [IO.File]::ReadAllBytes($backup)
                if ((Get-BF4Sha256Hex -Bytes $bytes) -ne $op.pre_sha256 -or
                    (Get-BF4Sha256Hex -Bytes (Get-PatchedVersionsBytes $bytes $Manifest)) -ne $op.post_sha256) { throw 'Versions repair backup is invalid.' }
            } elseif ($Journal.status -ne 'planned') { throw 'Repair versions backup is missing.' }
        } else {
            $f = Get-ManifestFileById $Manifest $op.id
            $parent = @($Context.ManagedState.operations | Where-Object { $_.id -eq $op.id })
            if ($parent.Count -ne 1 -or $op.root -ne $f.root -or $op.relative_path -ne $f.relative_path -or
                $op.pre_sha256 -ne $f.source_sha256 -or $op.post_sha256 -ne $f.target_sha256 -or
                $op.backup_relative -ne $parent[0].backup_relative) { throw 'Repair operation does not match pinned source/target and original backup.' }
        }
        $path = Resolve-TargetPath $op.root $op.relative_path $Context
        Assert-RegularTargetFile $path
        $hash = Get-BF4Sha256Hex -Path $path
        if ($hash -ne $op.pre_sha256 -and $hash -ne $op.post_sha256) { throw "External change during repair: $($op.id)" }
    }
}

function Remove-RepairScratch {
    param([object]$Journal, [object]$Context)
    Remove-Stages @($Journal.operations) $Context
    # Only this journal's tiny versions snapshot is disposable. Original
    # install backups, including the CAS, are never removed here.
    $relative = 'repairs\'+$Journal.id+'\versions-before.bin'
    $path = Resolve-BF4ContainedPath $Context.StateInstanceRoot $relative
    if ([IO.File]::Exists($path)) { Assert-RegularTargetFile $path; Remove-Item -LiteralPath $path -Force }
}

function Undo-Repair {
    param([object]$Journal, [object]$Manifest, [object]$Context)
    Assert-NoGameProcesses
    Assert-RepairJournal $Journal $Manifest $Context
    $Journal.status='rolling_back'; Save-RepairJournal $Journal $Context
    foreach ($op in @($Journal.operations | Sort-Object commit_order -Descending)) {
        $path = Resolve-TargetPath $op.root $op.relative_path $Context
        $hash = Get-BF4Sha256Hex -Path $path
        if ($hash -eq $op.pre_sha256) { Set-FileMetadata $path $op.metadata; continue }
        $backup = Resolve-BF4ContainedPath $Context.StateInstanceRoot $op.backup_relative
        Assert-RegularTargetFile $backup
        if ((Get-BF4Sha256Hex -Path $backup) -ne $op.pre_sha256) { throw 'Repair rollback backup hash mismatch.' }
        Assert-NoGameProcesses
        $stage = New-CopyStageFile $path $backup $op.pre_sha256
        try { Invoke-AtomicReplace $stage $path $op.metadata $op.post_sha256 $op.pre_sha256 $null }
        finally { if ([IO.File]::Exists($stage)) { Remove-Item -LiteralPath $stage -Force } }
    }
    Remove-Stages @($Journal.operations) $Context
    Remove-OrphanStages $Context $Manifest
    $Journal.status='rolled_back'; $Journal.completed_utc=(Get-Date).ToUniversalTime().ToString('o')
    Save-RepairJournal $Journal $Context
    Remove-RepairScratch $Journal $Context
}

function New-RepairOperation {
    param([object]$Descriptor, [string]$Path, [string]$Before, [string]$After, [string]$Backup, [string]$Kind, [int]$Order)
    return [pscustomobject]@{
        id=$Descriptor.id; root=$Descriptor.root; relative_path=$Descriptor.relative_path; kind=$Kind; commit_order=$Order
        pre_sha256=$Before; post_sha256=$After; backup_relative=$Backup; metadata=(Get-FileMetadata $Path)
        stage_path=$null; committed=$false; temporary_access_rules_removed=0
    }
}

function Invoke-RepairAction {
    param([object]$Manifest, [object]$Context, [string]$PackageRoot)
    $pending = Read-RepairJournal $Context
    if ($null -ne $pending -and $pending.status -notin @('repaired','rolled_back')) {
        try { Undo-Repair $pending $Manifest $Context }
        catch { $pending.status='rollback_failed'; $pending.failure=$_.Exception.Message; Save-RepairJournal $pending $Context; throw }
        Write-Host 'Interrupted repair restored its exact pre-repair state; continuing repair.'
        $Context = Assert-Environment $Manifest $Context.GameRoot $Context.TwinkleRoot ([IO.Directory]::GetParent([IO.Directory]::GetParent($Context.StateInstanceRoot).FullName).FullName) -AllowKnownMismatch
        Assert-RepairOriginals $Manifest $Context
    }
    if ($Context.Classification -eq 'ExactTarget') { Write-Host 'HEALTHY: patch is intact; no files, state or backups were written.'; return }
    $id='repair-'+[guid]::NewGuid().ToString('N')
    $ops=@()
    foreach ($f in @($Context.FileStates | Where-Object {$_.Kind -eq 'Source'})) {
        $parent=@($Context.ManagedState.operations | Where-Object {$_.id -eq $f.Descriptor.id})[0]
        $ops+=New-RepairOperation $f.Descriptor $f.Path $f.Hash $f.Descriptor.target_sha256 $parent.backup_relative $f.Descriptor.kind $f.Descriptor.commit_order
    }
    if ($Context.VersionsState.Kind -ne 'Target') {
        $v=[pscustomobject]@{id='twinkle-versions';root='twinkle';relative_path=$Manifest.versions.relative_path}
        $ops+=New-RepairOperation $v $Context.VersionsState.Path $Context.VersionsState.Hash $Manifest.versions.target_sha256 ('repairs\'+$id+'\versions-before.bin') 'versions-crc' 1000
    }
    Assert-NoGameProcesses
    Assert-TransactionSpace $Manifest $Context
    $journal=[pscustomobject]@{schema=1;id=$id;parent_transaction_id=$Context.ManagedState.transaction_id;game_root=$Context.GameRoot;twinkle_root=$Context.TwinkleRoot;status='planned';created_utc=(Get-Date).ToUniversalTime().ToString('o');completed_utc=$null;failure=$null;operations=$ops}
    $dir=Resolve-BF4ContainedPath $Context.StateInstanceRoot ('repairs\'+$id)
    [void](New-Item -ItemType Directory -Path $dir); [void](Assert-LocalNtfsPath $dir)
    Save-RepairJournal $journal $Context
    try {
        foreach ($op in $ops) {
            $path=Resolve-TargetPath $op.root $op.relative_path $Context
            if ((Get-BF4Sha256Hex -Path $path) -ne $op.pre_sha256) { throw 'Resource changed before repair staging.' }
            if ($op.kind -eq 'versions-crc') {
                $before=[IO.File]::ReadAllBytes($path)
                if ((Get-BF4Sha256Hex -Bytes $before) -ne $op.pre_sha256) { throw 'Cache changed before repair snapshot.' }
                Write-DurableBytes (Resolve-BF4ContainedPath $Context.StateInstanceRoot $op.backup_relative) $before -CreateNew
                $after=Get-PatchedVersionsBytes $before $Manifest
                $op.stage_path=New-StageFile $path $after $op.post_sha256
            } elseif ($op.kind -eq 'bf4dxr1') {
                $f=Get-ManifestFileById $Manifest $op.id
                $patch=Resolve-BF4ContainedPath $PackageRoot $f.patch_path
                $op.stage_path=New-BF4StreamDeltaStage -Target $path -Patch $patch -ExpectedHash $op.post_sha256
            } else {
                $op.stage_path=New-StageFile $path (Get-DesiredBytes $op $Manifest $Context $PackageRoot) $op.post_sha256
            }
            Save-RepairJournal $journal $Context
        }
        $journal.status='prepared'; Save-RepairJournal $journal $Context
        $journal.status='committing'; Save-RepairJournal $journal $Context
        foreach ($op in @($ops | Sort-Object commit_order)) {
            Assert-NoGameProcesses
            $path=Resolve-TargetPath $op.root $op.relative_path $Context
            Invoke-AtomicReplace $op.stage_path $path $op.metadata $op.pre_sha256 $op.post_sha256 $op
            Save-RepairJournal $journal $Context
        }
        foreach ($f in $Manifest.files) {
            if ((Get-BF4Sha256Hex -Path (Resolve-TargetPath $f.root $f.relative_path $Context)) -ne $f.target_sha256) { throw 'Final repair resource verification failed.' }
        }
        if (-not (Test-ManagedVersionsNow $Context 'Target')) { throw 'Final repaired CRC verification failed.' }
        $journal.status='repaired'; $journal.completed_utc=(Get-Date).ToUniversalTime().ToString('o')
        Save-RepairJournal $journal $Context
    } catch {
        $failure=$_.Exception.Message
        try { Undo-Repair $journal $Manifest $Context }
        catch { $journal.status='rollback_failed';$journal.failure=$failure+'; rollback: '+$_.Exception.Message;Save-RepairJournal $journal $Context;throw $journal.failure }
        throw "Repair failed and restored its pre-repair state: $failure"
    }
    Remove-RepairScratch $journal $Context
    Write-Host "REPAIRED: $($ops.Count) changed resource/cache entries restored; original uninstall backups preserved."
}

function Invoke-MaintenanceAction {
    param([string]$Action, [object]$Manifest, [object]$Context, [string]$PackageRoot)
    Assert-NoGameProcesses
    if ($Context.Classification -eq 'Unsupported') { throw 'Unknown resource bytes found. This game version or mod is not supported.' }
    $journal=Read-RepairJournal $Context
    $pending=($null -ne $journal -and $journal.status -notin @('repaired','rolled_back'))
    if ($null -eq $Context.ManagedState -or $Context.ManagedState.status -in @('uninstalled','rolled_back')) {
        if ($Action -eq 'Repair') { throw 'No active managed installation. Use Install.cmd first; original backups are required for Repair.' }
        Write-Host 'NOT_INSTALLED: no active managed installation. Use Install.cmd for supported original files.'; return 2
    }
    Assert-RepairOriginals $Manifest $Context
    if ($Action -eq 'Check') {
        if ($pending) { Assert-RepairJournal $journal $Manifest $Context; Write-Host 'RECOVERY_REQUIRED: close BF4 and run Repair.cmd with the same StateRoot.'; return 3 }
        if ($Context.Classification -eq 'ExactTarget') { Write-Host 'HEALTHY: all patched resources, managed CRCs and original recovery backups verified. Check made no writes.'; return 0 }
        $count=@($Context.FileStates | Where-Object {$_.Kind -eq 'Source'}).Count
        Write-Host "REPAIRABLE: $count known original resource files and/or managed cache CRCs need repair. Run Repair.cmd. Check made no writes."; return 2
    }
    Assert-MetadataRestoreAuthority $Context
    Invoke-RepairAction $Manifest $Context $PackageRoot
    return 0
}
