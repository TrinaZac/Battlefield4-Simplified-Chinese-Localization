﻿# Apply only the pinned SHA-1 keys in a structurally valid Frostbite catalog.
# All unrelated records and their order are preserved byte for byte.
function Get-BF4CatalogState {
    param([byte[]]$Bytes,[object[]]$Updates)
    if (-not ('BF4Release.KeyedCatalog' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
namespace BF4Release {
 public sealed class CatalogState {
  public byte[] SourceBytes;
  public byte[] TargetBytes;
  public string Kind;
 }
 public static class KeyedCatalog {
  static byte[] Key(string hex) {
   if(hex==null || hex.Length!=40) throw new InvalidDataException("Invalid catalog key");
   byte[] key=new byte[20];
   for(int i=0;i<20;i++) key[i]=Convert.ToByte(hex.Substring(i*2,2),16);
   return key;
  }
  static bool Equal(byte[] bytes,int at,byte[] key) {
   for(int i=0;i<20;i++) if(bytes[at+i]!=key[i]) return false;
   return true;
  }
  public static CatalogState Analyze(byte[] bytes,string[] source,string[] target,
                                    uint[] offsets,uint[] sizes,uint[] cas) {
   if(bytes==null || bytes.Length<16 || (bytes.Length-16)%32!=0 ||
      Encoding.ASCII.GetString(bytes,0,16)!="NyanNyanNyanNyan")
    throw new InvalidDataException("Invalid Frostbite catalog layout");
   int count=source.Length;
   if(count<1 || target.Length!=count || offsets.Length!=count || sizes.Length!=count || cas.Length!=count)
    throw new InvalidDataException("Invalid catalog updates");
   byte[][] a=new byte[count][],b=new byte[count][];
   int[] seen=new int[count]; int originals=0,localized=0;
   for(int n=0;n<count;n++){a[n]=Key(source[n]);b[n]=Key(target[n]);
    if(source[n]==target[n]) throw new InvalidDataException("Unchanged catalog key");}
   CatalogState result=new CatalogState();
   result.SourceBytes=(byte[])bytes.Clone();result.TargetBytes=(byte[])bytes.Clone();
   for(int p=16;p<bytes.Length;p+=32) for(int n=0;n<count;n++) {
    bool original=Equal(bytes,p,a[n]),patched=Equal(bytes,p,b[n]);
    if(!original && !patched) continue;
    if(++seen[n]!=1) throw new InvalidDataException("Duplicate managed catalog record");
    if(BitConverter.ToUInt32(bytes,p+20)!=offsets[n] || BitConverter.ToUInt32(bytes,p+24)!=sizes[n] ||
       BitConverter.ToUInt32(bytes,p+28)!=cas[n])
     throw new InvalidDataException("Managed catalog resource location or length changed");
    Buffer.BlockCopy(a[n],0,result.SourceBytes,p,20);
    Buffer.BlockCopy(b[n],0,result.TargetBytes,p,20);
    if(original) originals++; else localized++;
   }
   for(int n=0;n<count;n++) if(seen[n]!=1) throw new InvalidDataException("Managed catalog record is missing");
   result.Kind=originals==count?"Source":localized==count?"Target":"Mixed";
   return result;
  }
 }
}
'@
    }
    return [BF4Release.KeyedCatalog]::Analyze($Bytes,
        [string[]]@($Updates | ForEach-Object {$_.source_sha1}),
        [string[]]@($Updates | ForEach-Object {$_.target_sha1}),
        [uint32[]]@($Updates | ForEach-Object {$_.offset}),
        [uint32[]]@($Updates | ForEach-Object {$_.size}),
        [uint32[]]@($Updates | ForEach-Object {$_.cas_index}))
}
