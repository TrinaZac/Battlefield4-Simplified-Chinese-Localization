﻿[CmdletBinding()]
param(
    [ValidateSet('Install', 'Uninstall', 'Check', 'Repair')]
    [string]$Action = 'Install',
    [string]$GameRoot,
    [string]$TwinkleRoot,
    [string]$StateRoot,
    [switch]$AdoptExistingExact
)

# Required BF4Patch.Core.ps1 interfaces:
# Get-BF4RequiredProperty, Get-BF4Sha256Hex, Assert-BF4SafeRelativePath,
# Resolve-BF4ContainedPath, Get-BF4Crc32Bzip2, Read-BF4VersionsBytes,
# Update-BF4VersionsCrcBytes, Apply-BF4JsonPatchBytes, Apply-BF4DeltaBytes,
# Get-BF4FileMetadata, Set-BF4FileMetadata, Invoke-BF4AtomicReplace,
# Write-BF4DurableJson.
# Saved with a UTF-8 BOM for Windows PowerShell 5.1 Chinese status messages.

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-BF4Status {
    param([string]$Message)
    Write-Host ('[BF4] ' + $Message)
}

function Write-BF4ItemStatus {
    param([string]$Phase, [int]$Index, [int]$Total, [string]$Id)
    $labels = @{
        'static-base-zh-sb' = '本体文字'; 'static-base-zh-toc' = '本体文字索引'
        'static-update-zh-sb' = '更新包文字'; 'static-update-zh-toc' = '更新包文字索引'
        'embedded-cas_09-cas' = '界面资源（约 1 GB，请稍候）'
        'embedded-cas-cat' = '界面资源索引'; 'embedded-FrontEndChunks-toc' = '前端资源目录'
        'font-ARHeitiMediumB5' = '中文字体 1'; 'font-FuturaMaxiBook' = '中文字体 2'
        'twinkle-zh-tw-a343' = '主界面文字'; 'twinkle-zh-tw-a075' = '前端设置文字'
        'twinkle-versions' = '客户端校验记录'
    }
    $label = $labels[$Id]
    if ([string]::IsNullOrEmpty($label)) { $label = '资源文件' }
    Write-BF4Status ('{0}（{1}/{2}）：{3}' -f $Phase, $Index, $Total, $label)
}


function Read-StrictUtf8Text {
    param([Parameter(Mandatory = $true)][string]$Path)
    $encoding = New-Object System.Text.UTF8Encoding($false, $true)
    return [System.IO.File]::ReadAllText($Path, $encoding)
}

function Read-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not [System.IO.File]::Exists($Path)) {
        throw "Required JSON file is missing: $Path"
    }
    try {
        return (Read-StrictUtf8Text -Path $Path) | ConvertFrom-Json
    }
    catch {
        throw "Invalid JSON file '$Path': $($_.Exception.Message)"
    }
}

function Get-ObjectProperty {
    param(
        [Parameter(Mandatory = $true)][AllowNull()][object]$Object,
        [Parameter(Mandatory = $true)][string]$Name,
        [switch]$Optional
    )
    if ($null -eq $Object) {
        if ($Optional) { return $null }
        throw "Required property '$Name' was requested from null."
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        if ($Optional) { return $null }
        throw "Required property '$Name' is missing."
    }
    return $property.Value
}

function Test-HexDigestEqual {
    param([string]$Left, [string]$Right)
    if ($null -eq $Left -or $null -eq $Right) { return $false }
    return $Left.Equals($Right, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-CanonicalDirectory {
    param([Parameter(Mandatory = $true)][string]$Path)
    $full = [System.IO.Path]::GetFullPath($Path).TrimEnd([char]'\', [char]'/')
    if (-not [System.IO.Directory]::Exists($full)) {
        throw "Directory does not exist: $full"
    }
    return $full
}

function Get-NearestExistingPath {
    param([Parameter(Mandatory = $true)][string]$Path)
    $candidate = [System.IO.Path]::GetFullPath($Path)
    while (-not [System.IO.Directory]::Exists($candidate) -and -not [System.IO.File]::Exists($candidate)) {
        $parent = [System.IO.Directory]::GetParent($candidate)
        if ($null -eq $parent) { throw "No existing ancestor for path: $Path" }
        $candidate = $parent.FullName
    }
    return $candidate
}

function Assert-LocalNtfsPath {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$AllowMissingLeaf
    )
    $full = [System.IO.Path]::GetFullPath($Path)
    $existing = $full
    if (-not [System.IO.File]::Exists($existing) -and -not [System.IO.Directory]::Exists($existing)) {
        if (-not $AllowMissingLeaf) { throw "Path does not exist: $full" }
        $existing = Get-NearestExistingPath -Path $full
    }
    $root = [System.IO.Path]::GetPathRoot($existing)
    $drive = New-Object System.IO.DriveInfo($root)
    if (-not $drive.IsReady -or $drive.DriveFormat -ne 'NTFS') {
        throw "Only a ready local NTFS volume is supported: $full"
    }
    if ($drive.DriveType -ne [System.IO.DriveType]::Fixed -and
        $drive.DriveType -ne [System.IO.DriveType]::Removable) {
        throw "Network and non-local paths are not supported: $full"
    }

    $cursor = $existing
    while ($cursor.Length -ge $root.Length) {
        $item = Get-Item -LiteralPath $cursor -Force
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse points are not supported: $cursor"
        }
        if ($cursor.Equals($root, [System.StringComparison]::OrdinalIgnoreCase)) { break }
        $parent = [System.IO.Directory]::GetParent($cursor)
        if ($null -eq $parent) { break }
        $cursor = $parent.FullName
    }
    return $full
}

function Assert-RegularTargetFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    [void](Assert-LocalNtfsPath -Path $Path)
    $item = Get-Item -LiteralPath $Path -Force
    if (($item.Attributes -band [System.IO.FileAttributes]::Directory) -ne 0) {
        throw "Expected a regular file: $Path"
    }
    if (($item.Attributes -band [System.IO.FileAttributes]::Encrypted) -ne 0) {
        throw "EFS-encrypted files are not supported: $Path"
    }
    $streams = @(Get-Item -LiteralPath $Path -Stream * -ErrorAction Stop)
    foreach ($stream in $streams) {
        if ([string]$stream.Stream -ne ':$DATA') {
            throw "Alternate data streams are not supported on a target file: $Path"
        }
    }
}

function Assert-NoGameProcesses {
    $blocked = @('bf4', 'bf4_x86', 'ActivationUI', 'Link2EA')
    $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $blocked -contains $_.ProcessName })
    if ($running.Count -gt 0) {
        $names = (($running | Select-Object -ExpandProperty ProcessName -Unique) -join ', ')
        throw "Close the active Battlefield 4 game session before continuing: $names"
    }
}

function Get-VdfPairs {
    param([Parameter(Mandatory = $true)][string]$Path)
    $text = [System.IO.File]::ReadAllText($Path)
    $matches = [System.Text.RegularExpressions.Regex]::Matches(
        $text,
        '(?m)^\s*"([^"\r\n]+)"\s*"([^"\r\n]*)"\s*$'
    )
    $result = New-Object 'System.Collections.Generic.List[object]'
    foreach ($match in $matches) {
        [void]$result.Add([pscustomobject]@{ Key = $match.Groups[1].Value; Value = $match.Groups[2].Value })
    }
    return $result.ToArray()
}

function Get-UniqueVdfValue {
    param([object[]]$Pairs, [string]$Name, [switch]$Required)
    $values = @($Pairs | Where-Object { $_.Key.Equals($Name, [System.StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { $_.Value } | Select-Object -Unique)
    if ($values.Count -gt 1) { throw "VDF contains conflicting '$Name' values." }
    if ($values.Count -eq 0) {
        if ($Required) { throw "VDF is missing '$Name'." }
        return $null
    }
    return [string]$values[0]
}

function Get-SteamRoots {
    $roots = New-Object 'System.Collections.Generic.List[string]'
    $registryChecks = @(
        @{ Path = 'HKCU:\Software\Valve\Steam'; Names = @('SteamPath', 'InstallPath') },
        @{ Path = 'HKLM:\SOFTWARE\Valve\Steam'; Names = @('InstallPath', 'SteamPath') },
        @{ Path = 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam'; Names = @('InstallPath', 'SteamPath') }
    )
    foreach ($check in $registryChecks) {
        if (-not (Test-Path -LiteralPath $check.Path)) { continue }
        $properties = Get-ItemProperty -LiteralPath $check.Path
        foreach ($name in $check.Names) {
            $property = $properties.PSObject.Properties[$name]
            if ($null -ne $property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value)) {
                [void]$roots.Add([string]$property.Value)
            }
        }
    }

    $initial = @($roots.ToArray())
    foreach ($steamRoot in $initial) {
        $libraryFile = [System.IO.Path]::Combine($steamRoot, 'steamapps', 'libraryfolders.vdf')
        if (-not [System.IO.File]::Exists($libraryFile)) { continue }
        foreach ($pair in @(Get-VdfPairs -Path $libraryFile)) {
            if ($pair.Key.Equals('path', [System.StringComparison]::OrdinalIgnoreCase)) {
                [void]$roots.Add(([string]$pair.Value).Replace('\\', '\'))
            }
        }
    }
    return @($roots.ToArray() | ForEach-Object { try { [System.IO.Path]::GetFullPath($_) } catch {} } | Select-Object -Unique)
}

function Get-EABf4RegistryRecords {
    $paths = @(
        'HKLM:\SOFTWARE\EA Games\Battlefield 4',
        'HKLM:\SOFTWARE\WOW6432Node\EA Games\Battlefield 4',
        'HKCU:\SOFTWARE\EA Games\Battlefield 4',
        'HKCU:\SOFTWARE\WOW6432Node\EA Games\Battlefield 4'
    )
    $records = New-Object 'System.Collections.Generic.List[object]'
    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $properties = Get-ItemProperty -LiteralPath $path
        $installProperty = $properties.PSObject.Properties['Install Dir']
        $localeProperty = $properties.PSObject.Properties['locale']
        [void]$records.Add([pscustomobject]@{
            RegistryPath = $path
            InstallDir = if ($null -ne $installProperty) { [string]$installProperty.Value } else { $null }
            Locale = if ($null -ne $localeProperty) { [string]$localeProperty.Value } else { $null }
        })
    }
    return $records.ToArray()
}

function Resolve-GameRoot {
    param([string]$Override)
    if (-not [string]::IsNullOrWhiteSpace($Override)) {
        return (Get-CanonicalDirectory -Path $Override)
    }
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $eaExisting = New-Object 'System.Collections.Generic.List[string]'
    foreach ($steamRoot in @(Get-SteamRoots)) {
        [void]$candidates.Add([System.IO.Path]::Combine($steamRoot, 'steamapps', 'common', 'Battlefield 4'))
    }
    foreach ($record in @(Get-EABf4RegistryRecords)) {
        if (-not [string]::IsNullOrWhiteSpace($record.InstallDir)) { [void]$eaExisting.Add($record.InstallDir); [void]$candidates.Add($record.InstallDir) }
    }
    $existing = @($candidates.ToArray() | ForEach-Object {
        try {
            $full = [System.IO.Path]::GetFullPath($_)
            $common = [System.IO.Directory]::GetParent($full)
            if ($null -ne $common -and $common.Name.Equals('common', [System.StringComparison]::OrdinalIgnoreCase) -and
                $null -ne $common.Parent -and $common.Parent.Name.Equals('steamapps', [System.StringComparison]::OrdinalIgnoreCase) -and
                [System.IO.File]::Exists([System.IO.Path]::Combine($full, 'bf4.exe')) -and
                [System.IO.File]::Exists([System.IO.Path]::Combine($common.Parent.FullName, 'appmanifest_1238860.acf'))) { $full }
        } catch {}
    } | Select-Object -Unique)
    if ($existing.Count -eq 0) {
        $standalone = @($eaExisting.ToArray() | Where-Object { try { [System.IO.File]::Exists([System.IO.Path]::Combine([System.IO.Path]::GetFullPath($_), 'bf4.exe')) } catch { $false } })
        if ($standalone.Count -gt 0) { throw 'UNSUPPORTED_EA_STANDALONE: an EA App installation was found without a matching Steam appmanifest.' }
        throw 'Battlefield 4 Steam installation was not found.'
    }
    if ($existing.Count -gt 1) { throw 'Multiple Battlefield 4 installations were found. Use -GameRoot.' }
    return (Get-CanonicalDirectory -Path $existing[0])
}

function Resolve-TwinkleRoot {
    param([string]$Override)
    if (-not [string]::IsNullOrWhiteSpace($Override)) {
        return (Get-CanonicalDirectory -Path $Override)
    }
    $documents = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::MyDocuments)
    if ([string]::IsNullOrWhiteSpace($documents)) { throw 'Windows Documents Known Folder was not resolved.' }
    return (Get-CanonicalDirectory -Path ([System.IO.Path]::Combine($documents, 'Battlefield 4', 'twinkle')))
}

function Get-AppManifestPath {
    param([Parameter(Mandatory = $true)][string]$ResolvedGameRoot)
    $common = [System.IO.Directory]::GetParent($ResolvedGameRoot)
    if ($null -eq $common -or -not $common.Name.Equals('common', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'The game directory is not below steamapps\common.'
    }
    $steamApps = $common.Parent
    if ($null -eq $steamApps -or -not $steamApps.Name.Equals('steamapps', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'The game directory is not below a Steam library.'
    }
    $path = [System.IO.Path]::Combine($steamApps.FullName, 'appmanifest_1238860.acf')
    if (-not [System.IO.File]::Exists($path)) { throw "Steam appmanifest is missing: $path" }
    return $path
}

function Resolve-TargetPath {
    param([string]$RootName, [string]$RelativePath, [object]$Context)
    $root = $null
    if ($RootName -eq 'game') { $root = $Context.GameRoot }
    elseif ($RootName -eq 'twinkle') { $root = $Context.TwinkleRoot }
    else { throw "Unknown manifest root: $RootName" }
    return (Resolve-BF4ContainedPath -Root $root -RelativePath $RelativePath)
}

function Get-NormalizedVersionsPath {
    param([string]$Path)
    return (Assert-BF4SafeRelativePath -Path $Path).Replace('\', '/').ToLowerInvariant()
}

function Assert-ManifestShapeAndPackage {
    param([object]$Manifest, [string]$PackageRoot)
    $profile = Get-ObjectProperty -Object $Manifest -Name 'profile'
    if ([string](Get-ObjectProperty $profile 'store') -ne 'Steam' -or
        [string](Get-ObjectProperty $profile 'appid') -ne '1238860') {
        throw 'This installer supports only the pinned Steam BF4 profile.'
    }
    [void](Get-ObjectProperty $profile 'product')
    [void](Get-ObjectProperty $profile 'version')
    [void](Get-ObjectProperty $profile 'buildid')
    [void](Get-ObjectProperty $profile 'steam_language')
    [void](Get-ObjectProperty $profile 'locale')
    $bf4 = Get-ObjectProperty $profile 'bf4'
    foreach ($name in @('relative_path', 'size', 'sha256', 'file_version')) { [void](Get-ObjectProperty $bf4 $name) }

    $files = @(Get-ObjectProperty $Manifest 'files')
    if ($files.Count -ne 11) { throw "The release manifest must contain exactly eleven resource operations; found $($files.Count)." }
    $ids = @{}
    $orders = @{}
    $targets = @{}
    foreach ($file in $files) {
        foreach ($name in @('id','root','relative_path','kind','source_size','source_sha256','target_size','target_sha256','patch_path','patch_sha256','commit_order')) {
            [void](Get-ObjectProperty $file $name)
        }
        $id = [string]$file.id
        if ($ids.ContainsKey($id)) { throw "Duplicate manifest file id: $id" }
        $ids[$id] = $true
        $order = [int]$file.commit_order
        if ($orders.ContainsKey($order)) { throw "Duplicate manifest commit_order: $order" }
        $orders[$order] = $true
        if ($file.root -ne 'game' -and $file.root -ne 'twinkle') { throw "Invalid root for $id." }
        [void](Assert-BF4SafeRelativePath -Path ([string]$file.relative_path))
        $targetKey=([string]$file.root+'|'+[string]$file.relative_path).Replace('\','/').ToLowerInvariant()
        if($targets.ContainsKey($targetKey)){throw 'Duplicate manifest target path.'}
        $targets[$targetKey]=$true
        [void](Assert-BF4SafeRelativePath -Path ([string]$file.patch_path))
        $patchPath = Resolve-BF4ContainedPath -Root $PackageRoot -RelativePath ([string]$file.patch_path)
        Assert-RegularTargetFile -Path $patchPath
        $patchHash = Get-BF4Sha256Hex -Path $patchPath
        if (-not (Test-HexDigestEqual $patchHash ([string]$file.patch_sha256))) {
            throw "Package patch SHA-256 mismatch: $($file.patch_path)"
        }
        if ($file.kind -ne 'bf4dxr1' -and $file.kind -ne 'flat-json-key-patch') {
            throw "Unsupported patch kind for ${id}: $($file.kind)"
        }
    }

    $versions = Get-ObjectProperty $Manifest 'versions'
    foreach ($name in @('root','relative_path','source_size','source_sha256','target_sha256','record_count','updates')) { [void](Get-ObjectProperty $versions $name) }
    if ($versions.root -ne 'twinkle') { throw 'versions must be below the Twinkle root.' }
    [void](Assert-BF4SafeRelativePath -Path ([string]$versions.relative_path))
    if (@($versions.updates).Count -ne 4 -or $versions.mode -ne 'keyed-crc-v1') { throw 'versions must contain exactly four keyed CRC updates.' }
    foreach ($update in @($versions.updates)) {
        [void](Get-ObjectProperty $update 'path')
        if ($null -eq (Get-ObjectProperty $update 'expected_crc32_bzip2' -Optional) -and
            $null -eq (Get-ObjectProperty $update 'source_crc32_bzip2' -Optional)) {
            throw 'A versions update is missing its source CRC.'
        }
        [void](Get-ObjectProperty $update 'target_crc32_bzip2')
    }
    $observations = @(Get-ObjectProperty $Manifest 'observations')
    if ($observations.Count -lt 2) { throw 'The manifest observation set is incomplete.' }
    foreach ($observation in $observations) {
        foreach ($name in @('root','relative_path','size','sha256')) { [void](Get-ObjectProperty $observation $name) }
        [void](Assert-BF4SafeRelativePath -Path ([string]$observation.relative_path))
    }
}

function Get-FileState {
    param([string]$Path, [object]$Descriptor)
    Assert-RegularTargetFile -Path $Path
    $item = Get-Item -LiteralPath $Path -Force
    $hash = Get-BF4Sha256Hex -Path $Path
    $source = (([uint64]$item.Length -eq [uint64]$Descriptor.source_size) -and (Test-HexDigestEqual $hash ([string]$Descriptor.source_sha256)) )
    $target = (([uint64]$item.Length -eq [uint64]$Descriptor.target_size) -and (Test-HexDigestEqual $hash ([string]$Descriptor.target_sha256)) )
    if (-not $source -and -not $target) { $kind = 'Unsupported' }
    elseif ($source) { $kind = 'Source' }
    else { $kind = 'Target' }
    return [pscustomobject]@{ Path = $Path; Length = [uint64]$item.Length; Hash = $hash; Kind = $kind }
}

function Get-StateInstanceId {
    param([string]$ResolvedGameRoot, [string]$ResolvedTwinkleRoot)
    $identity = ($ResolvedGameRoot.ToLowerInvariant() + "`n" + $ResolvedTwinkleRoot.ToLowerInvariant())
    return (Get-BF4Sha256Hex -Bytes ([System.Text.Encoding]::UTF8.GetBytes($identity))).Substring(0, 24).ToLowerInvariant()
}

function Get-StateLocation {
    param([string]$Override, [object]$Context)
    $base = $Override
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = [System.IO.Path]::Combine([System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::CommonApplicationData), 'BF4SimplifiedChinesePatch-v1.0')
    }
    $baseFull = [System.IO.Path]::GetFullPath($base)
    [void](Assert-LocalNtfsPath -Path $baseFull -AllowMissingLeaf)
    return [System.IO.Path]::Combine($baseFull, 'instances', (Get-StateInstanceId $Context.GameRoot $Context.TwinkleRoot))
}

function Read-ManagedState {
    param([string]$InstanceRoot)
    $path = [System.IO.Path]::Combine($InstanceRoot, 'current.json')
    if (-not [System.IO.File]::Exists($path)) { return $null }
    Assert-RegularTargetFile -Path $path
    return (Read-JsonFile -Path $path)
}

function Assert-ManagedStateBinding {
    param([object]$State, [object]$Manifest, [object]$Context)
    if ([int](Get-ObjectProperty $State 'state_schema') -ne 1) { throw 'Unsupported managed-state schema.' }
    foreach ($name in @('product','version','action','status','mode','game_root','twinkle_root','transaction_relative','operations')) { [void](Get-ObjectProperty $State $name) }
    if ([string]$State.action -ne 'install' -and [string]$State.action -ne 'uninstall') { throw 'Managed state action is invalid.' }
    if (-not ([string]$State.product).Equals([string]$Manifest.profile.product, [System.StringComparison]::Ordinal) -or
        -not ([string]$State.version).Equals([string]$Manifest.profile.version, [System.StringComparison]::Ordinal) -or
        -not ([string]$State.game_root).Equals($Context.GameRoot, [System.StringComparison]::OrdinalIgnoreCase) -or
        -not ([string]$State.twinkle_root).Equals($Context.TwinkleRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Managed state does not match this package or target roots.'
    }
    if ([string]$State.status -eq 'rollback_failed') {
        throw 'A previous transaction has unresolved rollback failure. Use its recorded backups for recovery.'
    }
    $expected = @{}
    foreach ($file in @($Manifest.files)) { $expected[[string]$file.id] = ([string]$file.root + '|' + [string]$file.relative_path) }
    $expected['twinkle-versions'] = ([string]$Manifest.versions.root + '|' + [string]$Manifest.versions.relative_path)
    $ops = @($State.operations)
    if ($ops.Count -ne $expected.Count) { throw 'Managed-state operation count is invalid.' }
    foreach ($op in $ops) {
        foreach ($name in @('id','root','relative_path','pre_sha256','post_sha256','backup_relative','metadata')) { [void](Get-ObjectProperty $op $name) }
        $id = [string]$op.id
        if (-not $expected.ContainsKey($id) -or $expected[$id] -ne ([string]$op.root + '|' + [string]$op.relative_path)) {
            throw "Managed-state operation is outside this package: $id"
        }
        $expected.Remove($id)
    }
    if ($expected.Count -ne 0) { throw 'Managed state is missing package operations.' }
}

function Assert-Environment {
    param([object]$Manifest, [string]$GameOverride, [string]$TwinkleOverride, [string]$StateOverride, [switch]$AllowKnownMismatch)
    $resolvedGame = Resolve-GameRoot -Override $GameOverride
    $resolvedTwinkle = Resolve-TwinkleRoot -Override $TwinkleOverride
    [void](Assert-LocalNtfsPath -Path $resolvedGame)
    [void](Assert-LocalNtfsPath -Path $resolvedTwinkle)
    $context = [pscustomobject]@{ GameRoot = $resolvedGame; TwinkleRoot = $resolvedTwinkle; StateInstanceRoot = $null; FileStates = @(); VersionsState = $null; Classification = $null; ManagedState = $null }

    $appManifestPath = Get-AppManifestPath -ResolvedGameRoot $resolvedGame
    Assert-RegularTargetFile -Path $appManifestPath
    $pairs = @(Get-VdfPairs -Path $appManifestPath)
    if ((Get-UniqueVdfValue $pairs 'appid' -Required) -ne [string]$Manifest.profile.appid) { throw 'Steam appid mismatch.' }
    if ((Get-UniqueVdfValue $pairs 'buildid' -Required) -ne [string]$Manifest.profile.buildid) { throw 'Unsupported Steam buildid.' }
    if ((Get-UniqueVdfValue $pairs 'language' -Required) -ne [string]$Manifest.profile.steam_language) { throw 'Steam language must be tchinese.' }

    $eaRecords = @(Get-EABf4RegistryRecords)
    if ($eaRecords.Count -eq 0) { throw 'Battlefield 4 EA registry locale is missing.' }
    foreach ($record in $eaRecords) {
        if ([string]::IsNullOrWhiteSpace($record.Locale) -or $record.Locale -ne [string]$Manifest.profile.locale) {
            throw "EA registry locale mismatch at $($record.RegistryPath)."
        }
        if ([string]::IsNullOrWhiteSpace($GameOverride) -and -not [string]::IsNullOrWhiteSpace($record.InstallDir)) {
            $eaInstall = [System.IO.Path]::GetFullPath($record.InstallDir).TrimEnd([char]'\', [char]'/')
            if (-not $eaInstall.Equals($resolvedGame, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "EA registry Install Dir does not match the Steam game root at $($record.RegistryPath)."
            }
        }
    }

    $bf4Path = Resolve-BF4ContainedPath -Root $resolvedGame -RelativePath ([string]$Manifest.profile.bf4.relative_path)
    Assert-RegularTargetFile -Path $bf4Path
    $bf4Info = Get-Item -LiteralPath $bf4Path -Force
    if ([uint64]$bf4Info.Length -ne [uint64]$Manifest.profile.bf4.size -or
        -not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $bf4Path) ([string]$Manifest.profile.bf4.sha256))) {
        throw 'Unsupported bf4.exe bytes.'
    }
    $fileVersionRaw = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($bf4Path).FileVersion
    $fileVersionParts = @([System.Text.RegularExpressions.Regex]::Matches($fileVersionRaw, '[0-9]+') | ForEach-Object { $_.Value })
    $fileVersion = [string]::Join('.', $fileVersionParts)
    if ($fileVersion -ne [string]$Manifest.profile.bf4.file_version) { throw "Unsupported bf4.exe version: $fileVersionRaw" }

    foreach ($observation in @($Manifest.observations)) {
        $path = Resolve-TargetPath ([string]$observation.root) ([string]$observation.relative_path) $context
        Assert-RegularTargetFile -Path $path
        $info = Get-Item -LiteralPath $path -Force
        if ([uint64]$info.Length -ne [uint64]$observation.size -or
            -not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $path) ([string]$observation.sha256))) {
            throw "Active-resource observation mismatch: $($observation.relative_path)"
        }
        $exact = Get-ObjectProperty $observation 'exact_ascii_content' -Optional
        if ($null -ne $exact) {
            $actual = [System.Text.Encoding]::ASCII.GetString([System.IO.File]::ReadAllBytes($path))
            if (-not $actual.Equals([string]$exact, [System.StringComparison]::Ordinal)) {
                throw "Active selector content mismatch: $($observation.relative_path)"
            }
        }
    }

    $context.StateInstanceRoot = Get-StateLocation -Override $StateOverride -Context $context
    $context.ManagedState = Read-ManagedState -InstanceRoot $context.StateInstanceRoot
    if ($null -ne $context.ManagedState) { Assert-ManagedStateBinding $context.ManagedState $Manifest $context }
    Assert-NoPendingRepair -Context $context -AllowPending:$AllowKnownMismatch
    $recoveryStatuses = @('backup_manifest_written', 'backed_up', 'prepared', 'committing', 'rolling_back')
    $isRecoveryPending = ($null -ne $context.ManagedState -and $recoveryStatuses -contains [string]$context.ManagedState.status)

    $states = New-Object 'System.Collections.Generic.List[object]'
    $bf4FileProgress = 0
    foreach ($descriptor in @($Manifest.files)) {
        $bf4FileProgress++
        Write-BF4ItemStatus '核对游戏文件' $bf4FileProgress (@($Manifest.files).Count) ([string]$descriptor.id)
        $path = Resolve-TargetPath ([string]$descriptor.root) ([string]$descriptor.relative_path) $context
        $state = Get-FileState -Path $path -Descriptor $descriptor
        [void]$states.Add([pscustomobject]@{ Descriptor = $descriptor; Path = $path; Hash = $state.Hash; Kind = $state.Kind })
    }
    $context.FileStates = $states.ToArray()

    $versionsDescriptor = $Manifest.versions
    $versionsPath = Resolve-TargetPath ([string]$versionsDescriptor.root) ([string]$versionsDescriptor.relative_path) $context
    Assert-RegularTargetFile -Path $versionsPath
    $versionsBytes = [System.IO.File]::ReadAllBytes($versionsPath)
    $records = @(Read-BF4VersionsBytes -Bytes $versionsBytes)
    $versionsHash = Get-BF4Sha256Hex -Bytes $versionsBytes
    $sourceUpdates=@();$targetUpdates=@();$versionKinds=@()
    foreach($update in @($versionsDescriptor.updates)) {
        $entry=@($records | Where-Object {$_.NormalizedPath -eq (Get-NormalizedVersionsPath ([string]$update.path))})
        if($entry.Count -ne 1){throw "versions record is missing or not unique: $($update.path)"}
        $crc=$entry[0].StoredCrc32Bzip2Hex
        if($crc -eq $update.source_crc32_bzip2){$versionKinds+='Source'}
        elseif($crc -eq $update.target_crc32_bzip2){$versionKinds+='Target'}
        else {throw "Unsupported versions CRC: $($update.path)"}
        if($crc -ne $update.source_crc32_bzip2){$sourceUpdates+=[pscustomobject]@{path=$update.path;expected_crc32_bzip2=$crc;target_crc32_bzip2=$update.source_crc32_bzip2}}
        if($crc -ne $update.target_crc32_bzip2){$targetUpdates+=[pscustomobject]@{path=$update.path;expected_crc32_bzip2=$crc;target_crc32_bzip2=$update.target_crc32_bzip2}}
    }
    [byte[]]$sourceVersions=$versionsBytes.Clone()
    [byte[]]$targetVersions=$versionsBytes.Clone()
    if($sourceUpdates.Count -gt 0){$sourceVersions=Update-BF4VersionsCrcBytes -Bytes $versionsBytes -Updates $sourceUpdates -ExpectedUpdateCount $sourceUpdates.Count}
    if($targetUpdates.Count -gt 0){$targetVersions=Update-BF4VersionsCrcBytes -Bytes $versionsBytes -Updates $targetUpdates -ExpectedUpdateCount $targetUpdates.Count}
    $versionsDescriptor.source_sha256=Get-BF4Sha256Hex -Bytes $sourceVersions
    $versionsDescriptor.target_sha256=Get-BF4Sha256Hex -Bytes $targetVersions
    $versionsDescriptor.source_size=$versionsBytes.LongLength
    $versionsDescriptor.target_size=$versionsBytes.LongLength
    $versionsDescriptor.record_count=$records.Count
    if(@($versionKinds | Where-Object {$_ -eq 'Source'}).Count -eq 4){$versionsKind='Source'}
    elseif(@($versionKinds | Where-Object {$_ -eq 'Target'}).Count -eq 4){$versionsKind='Target'}
    else {$versionsKind='Mixed'}
    $context.VersionsState = [pscustomobject]@{ Descriptor = $versionsDescriptor; Path = $versionsPath; Hash = $versionsHash; Kind = $versionsKind; Bytes = $versionsBytes; Records = $records }

    $recordMap = @{}
    foreach ($record in $records) { $recordMap[$record.NormalizedPath] = $record }
    foreach ($fileState in @($context.FileStates)) {
        $versionsPathValue = Get-ObjectProperty $fileState.Descriptor 'versions_path' -Optional
        if ($null -eq $versionsPathValue) { continue }
        $normalized = Get-NormalizedVersionsPath -Path ([string]$versionsPathValue)
        if (-not $recordMap.ContainsKey($normalized)) { throw "versions record is missing: $versionsPathValue" }
        $sourceCrc = Get-ObjectProperty $fileState.Descriptor 'source_crc32_bzip2'
        $targetCrc = Get-ObjectProperty $fileState.Descriptor 'target_crc32_bzip2'
        [uint32]$storedCrc = [uint32]$recordMap[$normalized].StoredCrc32Bzip2
        if ($fileState.Kind -eq 'Source') { $expectedCrc = $sourceCrc }
        elseif ($fileState.Kind -eq 'Target') { $expectedCrc = $targetCrc }
        else { continue }
        # Get-FileState already matched exact length and SHA-256. Each pinned
        # byte sequence has an independently verified CRC in the manifest.
        # Compare that CRC without a slow interpreted 10 MB byte loop.
        [uint32]$actualCrc = Convert-BF4Crc32Value -Value $expectedCrc
        if ($storedCrc -ne $actualCrc) {
            if (-not $isRecoveryPending -and -not $AllowKnownMismatch) { throw "versions CRC does not match the active file: $versionsPathValue" }
            [uint32]$sourceCrcValue = Convert-BF4Crc32Value -Value $sourceCrc
            [uint32]$targetCrcValue = Convert-BF4Crc32Value -Value $targetCrc
            if ($storedCrc -ne $sourceCrcValue -and $storedCrc -ne $targetCrcValue) {
                throw "versions has an unsupported CRC during managed recovery: $versionsPathValue"
            }
        }
    }

    $allKinds = @($context.FileStates | ForEach-Object { $_.Kind }) + @($versionsKind)
    if (@($allKinds | Where-Object { $_ -eq 'Source' }).Count -eq 12) { $context.Classification = 'Pristine' }
    elseif (@($allKinds | Where-Object { $_ -eq 'Target' }).Count -eq 12) { $context.Classification = 'ExactTarget' }
    elseif (@($allKinds | Where-Object { $_ -eq 'Unsupported' }).Count -gt 0) { $context.Classification = 'Unsupported' }
    else { $context.Classification = 'Mixed' }

    return $context
}

function Assert-TransactionSpace {
    param([object]$Manifest,[object]$Context)
    $needed=@{}
    foreach($f in @($Manifest.files)+@($Manifest.versions)){
        $target=Resolve-TargetPath ([string]$f.root) ([string]$f.relative_path) $Context
        $volume=[IO.Path]::GetPathRoot($target)
        if(-not $needed.ContainsKey($volume)){$needed[$volume]=[uint64]268435456}
        $needed[$volume]+=[uint64]$f.source_size+[uint64]$f.target_size
        $backupVolume=[IO.Path]::GetPathRoot($Context.StateInstanceRoot)
        if(-not $needed.ContainsKey($backupVolume)){$needed[$backupVolume]=[uint64]268435456}
        $needed[$backupVolume]+=[uint64][Math]::Max([double]$f.source_size,[double]$f.target_size)
    }
    foreach($volume in $needed.Keys){
        $drive=New-Object IO.DriveInfo($volume)
        if([uint64]$drive.AvailableFreeSpace -lt $needed[$volume]){throw "Insufficient free space on $volume; required $($needed[$volume]) bytes."}
    }
}

function Get-FileMetadata {
    param([Parameter(Mandatory = $true)][string]$Path)
    return (Get-BF4FileMetadata -Path $Path)
}

function Assert-MetadataRestoreAuthority {
    param([object]$Context)
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    $elevated = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    $paths = @($Context.FileStates | ForEach-Object { $_.Path }) + @($Context.VersionsState.Path)
    $owners = New-Object 'System.Collections.Generic.List[string]'
    foreach ($path in $paths) {
        $security = (New-Object System.IO.FileInfo($path)).GetAccessControl([System.Security.AccessControl.AccessControlSections]::Owner)
        [void]$owners.Add($security.GetOwner([System.Security.Principal.SecurityIdentifier]).Value)
    }
    if ($null -ne $Context.ManagedState) {
        foreach ($op in $Context.ManagedState.operations) {
            $raw = New-Object System.Security.AccessControl.RawSecurityDescriptor([Convert]::FromBase64String($op.metadata.security_descriptor_base64), 0)
            [void]$owners.Add($raw.Owner.Value)
        }
    }
    foreach ($owner in $owners) {
        if ($owner -eq $identity.User.Value) { continue }
        if ($owner -eq 'S-1-5-32-544' -and $elevated) { continue }
        if ($owner -eq 'S-1-5-32-544') {
            throw 'Administrator privileges are required to preserve the original file owner. Right-click Install.cmd or Uninstall.cmd and choose Run as administrator. No resource changes were started.'
        }
        throw 'A target has an unsupported file owner. No resource changes were started; preserve its permissions and use support diagnostics.'
    }
}

function Set-FileMetadata {
    param([string]$Path, [object]$Metadata)
    # Untouched deny-ACL targets require no write during rollback. Access time
    # is deliberately excluded because hashing itself can update it.
    $now = Get-BF4FileMetadata -Path $Path
    $same = Test-BF4SecurityDescriptorEquivalent ([Convert]::FromBase64String($now.security_descriptor_base64)) ([Convert]::FromBase64String($Metadata.security_descriptor_base64))
    foreach ($key in @('attributes','creation_time_utc_ticks','last_write_time_utc_ticks')) {
        if ($now.$key -ne $Metadata.$key) { $same = $false }
    }
    if ($same) { return }
    [void](Enable-BF4TemporaryAtomicReplaceAccess -Path $Path)
    Set-BF4FileMetadata -Path $Path -Metadata $Metadata
}

function Write-DurableBytes {
    param([string]$Path, [byte[]]$Bytes, [switch]$CreateNew)
    $mode = if ($CreateNew) { [System.IO.FileMode]::CreateNew } else { [System.IO.FileMode]::Create }
    $stream = New-Object System.IO.FileStream($Path, $mode, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None, 65536, [System.IO.FileOptions]::WriteThrough)
    try {
        $stream.Write($Bytes, 0, $Bytes.Length)
        $stream.Flush($true)
    }
    finally { $stream.Dispose() }
}

function Copy-DurableFile {
    param([string]$Source, [string]$Destination)
    $input = New-Object System.IO.FileStream($Source, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try {
        $output = New-Object System.IO.FileStream($Destination, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None, 65536, [System.IO.FileOptions]::WriteThrough)
        try { $input.CopyTo($output); $output.Flush($true) } finally { $output.Dispose() }
    }
    finally { $input.Dispose() }
}

function Write-DurableJson {
    param([string]$Path, [object]$Object)
    [void](Write-BF4DurableJson -Path $Path -Value $Object -Depth 32)
}

function Save-Transaction {
    param([object]$Transaction, [string]$InstanceRoot, [switch]$AsCurrent)
    $txPath = Resolve-BF4ContainedPath -Root $InstanceRoot -RelativePath ([string]$Transaction.transaction_relative)
    Write-DurableJson -Path $txPath -Object $Transaction
    if ($AsCurrent) { Write-DurableJson -Path ([System.IO.Path]::Combine($InstanceRoot, 'current.json')) -Object $Transaction }
}

function New-OperationList {
    param([object]$Manifest, [object]$Context, [switch]$Adopt)
    $operations = New-Object 'System.Collections.Generic.List[object]'
    foreach ($fileState in @($Context.FileStates)) {
        $descriptor = $fileState.Descriptor
        [void]$operations.Add([pscustomobject]@{
            id = [string]$descriptor.id; root = [string]$descriptor.root; relative_path = [string]$descriptor.relative_path
            kind = [string]$descriptor.kind; commit_order = [int]$descriptor.commit_order
            pre_sha256 = if ($Adopt) { [string]$descriptor.target_sha256 } else { [string]$descriptor.source_sha256 }
            post_sha256 = [string]$descriptor.target_sha256
            pre_size = if ($Adopt) { [uint64]$descriptor.target_size } else { [uint64]$descriptor.source_size }
            post_size = [uint64]$descriptor.target_size
            backup_relative = $null; backup_verified = $false; metadata = $null; stage_path = $null; stage_verified = $false; commit_pending = $false; committed = $false; temporary_access_rules_removed = 0
        })
    }
    $maxOrder = (@($Manifest.files | ForEach-Object { [int]$_.commit_order }) | Measure-Object -Maximum).Maximum
    [void]$operations.Add([pscustomobject]@{
        id = 'twinkle-versions'; root = [string]$Manifest.versions.root; relative_path = [string]$Manifest.versions.relative_path
        kind = 'versions-crc'; commit_order = ([int]$maxOrder + 1)
        pre_sha256 = if ($Adopt) { [string]$Manifest.versions.target_sha256 } else { [string]$Manifest.versions.source_sha256 }
        post_sha256 = [string]$Manifest.versions.target_sha256
        pre_size = [uint64]$Manifest.versions.source_size; post_size = [uint64]$Manifest.versions.source_size
        backup_relative = $null; backup_verified = $false; metadata = $null; stage_path = $null; stage_verified = $false; commit_pending = $false; committed = $false; temporary_access_rules_removed = 0
    })
    return $operations.ToArray()
}

function Get-ManifestFileById {
    param([object]$Manifest, [string]$Id)
    $found = @($Manifest.files | Where-Object { ([string]$_.id).Equals($Id, [System.StringComparison]::Ordinal) })
    if ($found.Count -ne 1) { throw "Manifest file id is not unique: $Id" }
    return $found[0]
}

function Get-DesiredBytes {
    param([object]$Operation, [object]$Manifest, [object]$Context, [string]$PackageRoot)
    $path = Resolve-TargetPath ([string]$Operation.root) ([string]$Operation.relative_path) $Context
    $source = [System.IO.File]::ReadAllBytes($path)
    if ($Operation.kind -eq 'versions-crc') {
        $updates = New-Object 'System.Collections.Generic.List[object]'
        foreach ($raw in @($Manifest.versions.updates)) {
            $expected = Get-ObjectProperty $raw 'expected_crc32_bzip2' -Optional
            if ($null -eq $expected) { $expected = Get-ObjectProperty $raw 'source_crc32_bzip2' }
            [void]$updates.Add([pscustomobject]@{ path = [string]$raw.path; expected_crc32_bzip2 = $expected; target_crc32_bzip2 = $raw.target_crc32_bzip2 })
        }
        return ,(Update-BF4VersionsCrcBytes -Bytes $source -Updates $updates.ToArray() -ExpectedUpdateCount 4)
    }
    $descriptor = Get-ManifestFileById $Manifest ([string]$Operation.id)
    $patchPath = Resolve-BF4ContainedPath -Root $PackageRoot -RelativePath ([string]$descriptor.patch_path)
    if ($Operation.kind -eq 'bf4dxr1') {
        return ,(Apply-BF4DeltaBytes -SourceBytes $source -PatchBytes ([System.IO.File]::ReadAllBytes($patchPath)))
    }
    if ($Operation.kind -eq 'flat-json-key-patch') {
        $patchManifest = Read-JsonFile -Path $patchPath
        $records = @($patchManifest.files | Where-Object { ([string]$_.path).Equals([string]$Operation.relative_path, [System.StringComparison]::OrdinalIgnoreCase) })
        if ($records.Count -ne 1) { throw "JSON patch record is not unique: $($Operation.relative_path)" }
        return ,(Apply-BF4JsonPatchBytes -SourceBytes $source -FilePatch $records[0])
    }
    throw "Unsupported operation kind: $($Operation.kind)"
}

function New-StateDirectories {
    param([string]$InstanceRoot, [string]$TransactionId)
    $transactionRelative = 'transactions\' + $TransactionId + '\transaction.json'
    $txRoot = [System.IO.Path]::GetDirectoryName((Resolve-BF4ContainedPath -Root $InstanceRoot -RelativePath $transactionRelative))
    $backupRoot = [System.IO.Path]::Combine($txRoot, 'backups')
    [void](New-Item -ItemType Directory -Path $backupRoot -Force)
    [void](Assert-LocalNtfsPath -Path $txRoot)
    [void](Assert-LocalNtfsPath -Path $backupRoot)
    return [pscustomobject]@{ TransactionRelative = $transactionRelative; TransactionRoot = $txRoot; BackupRoot = $backupRoot }
}

function Initialize-TransactionAndBackups {
    param([object]$Transaction, [object]$Context, [string]$InstanceRoot, [object]$Directories, [switch]$AsCurrent)
    $index = 0
    foreach ($op in @($Transaction.operations)) {
        Write-BF4ItemStatus '核对备份前的文件' ($index + 1) (@($Transaction.operations).Count) ([string]$op.id)
        $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
        $actual = Get-BF4Sha256Hex -Path $target
        if (-not (Test-HexDigestEqual $actual ([string]$op.pre_sha256))) { throw "Pre-backup hash changed: $($op.id)" }
        $safeId = ([string]$op.id) -replace '[^A-Za-z0-9_.-]', '_'
        $backupRelative = 'transactions\' + $Transaction.transaction_id + '\backups\' + ('{0:D2}-{1}.bin' -f $index, $safeId)
        $op.backup_relative = $backupRelative
        $op.metadata = Get-FileMetadata -Path $target
        $index++
    }
    $Transaction.status = 'backup_manifest_written'
    Save-Transaction $Transaction $InstanceRoot -AsCurrent:$AsCurrent

    $bf4BackupProgress = 0
    foreach ($op in @($Transaction.operations)) {
        $bf4BackupProgress++
        Write-BF4ItemStatus '备份文件' $bf4BackupProgress (@($Transaction.operations).Count) ([string]$op.id)
        $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
        $backup = Resolve-BF4ContainedPath -Root $InstanceRoot -RelativePath ([string]$op.backup_relative)
        Copy-DurableFile -Source $target -Destination $backup
        if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $backup) ([string]$op.pre_sha256))) { throw "Backup verification failed: $($op.id)" }
        $op.backup_verified = $true
        Save-Transaction $Transaction $InstanceRoot -AsCurrent:$AsCurrent
    }
    $Transaction.status = 'backed_up'
    Save-Transaction $Transaction $InstanceRoot -AsCurrent:$AsCurrent
}

function New-StageFile {
    param([string]$Target, [byte[]]$Bytes, [string]$ExpectedHash)
    $stage = [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($Target), ('.bf4sc-' + [guid]::NewGuid().ToString('N') + '.stage'))
    try {
        Write-DurableBytes -Path $stage -Bytes $Bytes -CreateNew
        if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $stage) $ExpectedHash)) { throw "Stage verification failed for $Target" }
        return $stage
    } catch {if([IO.File]::Exists($stage)){[IO.File]::Delete($stage)};throw}
}

function New-CopyStageFile {
    param([string]$Target,[string]$Source,[string]$ExpectedHash)
    $stage=[IO.Path]::Combine([IO.Path]::GetDirectoryName($Target),('.bf4sc-'+[guid]::NewGuid().ToString('N')+'.stage'))
    try {
        Copy-DurableFile -Source $Source -Destination $stage
        if((Get-BF4Sha256Hex -Path $stage) -ne $ExpectedHash){throw 'Backup stage hash mismatch.'}
        return $stage
    }catch {if([IO.File]::Exists($stage)){[IO.File]::Delete($stage)};throw}
}

function Invoke-AtomicReplace {
    param(
        [string]$Stage,
        [string]$Target,
        [object]$Metadata,
        [string]$ExpectedBefore,
        [string]$ExpectedAfter,
        [AllowNull()][object]$Operation
    )
    if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $Target) $ExpectedBefore)) { throw "Target changed before atomic replace: $Target" }
    if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $Stage) $ExpectedAfter)) { throw "Stage changed before atomic replace: $Stage" }
    try {
        $attrs = (Get-Item -LiteralPath $Target -Force).Attributes
        if (($attrs -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
            [System.IO.File]::SetAttributes($Target, ($attrs -band (-bnot [System.IO.FileAttributes]::ReadOnly)))
        }
        $removedRules = Enable-BF4TemporaryAtomicReplaceAccess -Path $Target
        if ($null -ne $Operation) { $Operation.temporary_access_rules_removed = [int]$removedRules }
        [void](Invoke-BF4AtomicReplace -StagedPath $Stage -TargetPath $Target)
        if ($null -ne $Operation) { $Operation.committed = $true }
    }
    catch {
        $replaceFailure = $_.Exception
        if ([System.IO.File]::Exists($Target)) {
            $failureHash = Get-BF4Sha256Hex -Path $Target
            if (Test-HexDigestEqual $failureHash $ExpectedAfter) {
                if ($null -ne $Operation) { $Operation.committed = $true }
            }
            try { Set-FileMetadata -Path $Target -Metadata $Metadata }
            catch { throw "Atomic replacement failed and metadata recovery also failed for $Target`: $($replaceFailure.Message); metadata error: $($_.Exception.Message)" }
        }
        throw $replaceFailure
    }
    Set-FileMetadata -Path $Target -Metadata $Metadata
    if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $Target) $ExpectedAfter)) { throw "Post-replace verification failed: $Target" }
}

function Remove-Stages {
    param([object[]]$Operations, [object]$Context)
    foreach ($op in $Operations) {
        if ($null -eq $op.stage_path) { continue }
        $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
        $stage = [System.IO.Path]::GetFullPath([string]$op.stage_path)
        $targetDirectory = [System.IO.Path]::GetDirectoryName($target)
        if (-not [System.IO.Path]::GetDirectoryName($stage).Equals($targetDirectory, [System.StringComparison]::OrdinalIgnoreCase) -or
            [System.IO.Path]::GetFileName($stage) -notmatch '^\.bf4sc-[0-9a-f]{32}\.stage$') {
            throw "Recorded staging path is unsafe: $stage"
        }
        if ([System.IO.File]::Exists($stage)) {
            Assert-RegularTargetFile -Path $stage
            Remove-Item -LiteralPath $stage -Force
        }
    }
}

function Remove-OrphanStages {
    param([object]$Context, [object]$Manifest)
    $directories = New-Object 'System.Collections.Generic.List[string]'
    foreach ($file in @($Manifest.files)) {
        [void]$directories.Add([System.IO.Path]::GetDirectoryName((Resolve-TargetPath ([string]$file.root) ([string]$file.relative_path) $Context)))
    }
    [void]$directories.Add([System.IO.Path]::GetDirectoryName((Resolve-TargetPath ([string]$Manifest.versions.root) ([string]$Manifest.versions.relative_path) $Context)))
    foreach ($directory in @($directories.ToArray() | Select-Object -Unique)) {
        foreach ($candidate in @(Get-ChildItem -LiteralPath $directory -Force -File -Filter '.bf4sc-*.stage' -ErrorAction Stop)) {
            if ($candidate.Name -notmatch '^\.bf4sc-[0-9a-f]{32}\.stage$') { continue }
            Assert-RegularTargetFile -Path $candidate.FullName
            Remove-Item -LiteralPath $candidate.FullName -Force
        }
    }
}

function Invoke-InstallRollback {
    param([object]$Transaction, [object]$Context, [string]$InstanceRoot)
    $errors = New-Object 'System.Collections.Generic.List[string]'
    foreach ($op in @($Transaction.operations | Sort-Object commit_order -Descending)) {
        try {
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            $current = Get-BF4Sha256Hex -Path $target
            if (Test-HexDigestEqual $current ([string]$op.pre_sha256)) {
                Set-FileMetadata -Path $target -Metadata $op.metadata
                $op.committed = $false; $op.commit_pending = $false; continue
            }
            if (-not (Test-HexDigestEqual $current ([string]$op.post_sha256))) { throw 'Target has an unexpected hash during rollback.' }
            $backup = Resolve-BF4ContainedPath -Root $InstanceRoot -RelativePath ([string]$op.backup_relative)
            $stage = New-CopyStageFile -Target $target -Source $backup -ExpectedHash ([string]$op.pre_sha256)
            Invoke-AtomicReplace $stage $target $op.metadata ([string]$op.post_sha256) ([string]$op.pre_sha256) $null
            $op.committed = $false
            $op.commit_pending = $false
        }
        catch { [void]$errors.Add("$($op.id): $($_.Exception.Message)") }
    }
    Remove-Stages -Operations @($Transaction.operations) -Context $Context
    if ($errors.Count -gt 0) { throw ('Automatic rollback failed: ' + ($errors -join '; ')) }
}

function Invoke-IncompleteTransactionRecovery {
    param([object]$Manifest, [object]$Context)
    $state = $Context.ManagedState
    if ($null -eq $state) { return $false }
    $pendingStatuses = @('backup_manifest_written', 'backed_up', 'prepared', 'committing', 'resources_restored', 'rolling_back')
    if ($pendingStatuses -notcontains [string]$state.status) { return $false }

    Assert-NoGameProcesses
    try {
        $state.status = 'rolling_back'
        Save-Transaction $state $Context.StateInstanceRoot -AsCurrent
        foreach ($op in @($state.operations | Sort-Object commit_order -Descending)) {
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            $current = Get-BF4Sha256Hex -Path $target
            if (Test-HexDigestEqual $current ([string]$op.pre_sha256)) {
                Set-FileMetadata -Path $target -Metadata $op.metadata
                $op.committed = $false
                $op.commit_pending = $false
                Save-Transaction $state $Context.StateInstanceRoot -AsCurrent
                continue
            }
            if (-not (Test-HexDigestEqual $current ([string]$op.post_sha256))) {
                throw "Recovery found an unexpected target hash: $($op.id)"
            }
            $backup = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$op.backup_relative)
            Assert-RegularTargetFile -Path $backup
            if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $backup) ([string]$op.pre_sha256))) {
                throw "Recovery backup verification failed: $($op.id)"
            }
            $stage = New-CopyStageFile $target $backup ([string]$op.pre_sha256)
            Invoke-AtomicReplace $stage $target $op.metadata ([string]$op.post_sha256) ([string]$op.pre_sha256) $null
            $op.committed = $false
            $op.commit_pending = $false
            Save-Transaction $state $Context.StateInstanceRoot -AsCurrent
        }
        Remove-Stages @($state.operations) $Context
        Remove-OrphanStages $Context $Manifest
        $state.status = 'rolled_back'
        $state.recovered_utc = (Get-Date).ToUniversalTime().ToString('o')
        Save-Transaction $state $Context.StateInstanceRoot -AsCurrent

        if ([string]$state.action -eq 'uninstall') {
            $parentRelative = [string](Get-ObjectProperty $state 'parent_install_relative')
            $parentPath = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath $parentRelative
            $parent = Read-JsonFile -Path $parentPath
            Assert-ManagedStateBinding $parent $Manifest $Context
            if ([string]$parent.action -ne 'install' -or [string]$parent.status -ne 'installed' -or
                -not (Test-ManagedCurrentHashes $parent $Context)) {
                throw 'Recovered uninstall could not restore its installed parent state.'
            }
            Write-DurableJson ([System.IO.Path]::Combine($Context.StateInstanceRoot, 'current.json')) $parent
        }
        Write-Output 'An interrupted transaction was detected and safely rolled back.'
        return $true
    }
    catch {
        $recoveryError = $_.Exception.Message
        $state.status = 'rollback_failed'
        $state.rollback_failure = $recoveryError
        try { Save-Transaction $state $Context.StateInstanceRoot -AsCurrent } catch {}
        throw "Interrupted transaction recovery failed. Use its recorded backups. $recoveryError"
    }
}

function Test-ManagedCurrentHashes {
    param([object]$State, [object]$Context, [switch]$UsePre)
    $bf4VerifyProgress = 0
    foreach ($op in @($State.operations)) {
        $bf4VerifyProgress++
        Write-BF4ItemStatus '验证当前文件' $bf4VerifyProgress (@($State.operations).Count) ([string]$op.id)
        if($op.id -eq 'twinkle-versions') {
            $wanted=if($UsePre -and $State.mode -ne 'adopted'){'Source'}else{'Target'}
            if(-not (Test-ManagedVersionsNow $Context $wanted)){return $false};continue
        }
        $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
        $expected = if ($UsePre) { [string]$op.pre_sha256 } else { [string]$op.post_sha256 }
        if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $target) $expected)) { return $false }
    }
    return $true
}

function Test-ManagedPreStateMatchesClassification {
    param([object]$State, [object]$Context)
    foreach ($op in @($State.operations)) {
        if($op.id -eq 'twinkle-versions') {
            $wanted=if($State.mode -eq 'adopted'){'Target'}else{'Source'}
            if(-not (Test-ManagedVersionsNow $Context $wanted)){return $false};continue
        }
        $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
        if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $target) ([string]$op.pre_sha256))) { return $false }
    }
    return $true
}

function Test-ManagedVersionsNow {
    param([object]$Context,[string]$Wanted)
    # Recovery may have changed these CRCs since Assert-Environment. Read the
    # current bytes, not the stale classification captured before rollback.
    $records=@(Read-BF4VersionsBytes -Bytes ([IO.File]::ReadAllBytes($Context.VersionsState.Path)))
    foreach($u in @($Context.VersionsState.Descriptor.updates)){
        $r=@($records | Where-Object {$_.NormalizedPath -eq (Get-NormalizedVersionsPath ([string]$u.path))})
        if($r.Count -ne 1){return $false}
        $crc=if($Wanted -eq 'Source'){$u.source_crc32_bzip2}else{$u.target_crc32_bzip2}
        if($r[0].StoredCrc32Bzip2Hex -ne $crc){return $false}
    }
    return $true
}

function Invoke-InstallAction {
    param([object]$Manifest, [object]$Context, [string]$PackageRoot, [switch]$Adopt)
    if ($null -ne $Context.ManagedState -and $Context.ManagedState.status -eq 'installed') {
        if ($Context.Classification -ne 'ExactTarget' -or -not (Test-ManagedCurrentHashes $Context.ManagedState $Context)) {
            throw 'Managed installation state exists, but current resources do not match it.'
        }
        Write-BF4Status '补丁已安装，校验通过，无需重复安装。'
        Write-Output 'BF4 Simplified Chinese Patch is already installed and verified.'
        return
    }
    if ($null -ne $Context.ManagedState -and $Context.ManagedState.status -eq 'uninstalled') {
        if (-not (Test-ManagedPreStateMatchesClassification $Context.ManagedState $Context)) {
            throw 'Previous uninstalled state does not match current resources.'
        }
    }
    if ($null -ne $Context.ManagedState -and $Context.ManagedState.status -eq 'rolled_back') {
        if (-not (Test-ManagedPreStateMatchesClassification $Context.ManagedState $Context)) {
            throw 'Previous rolled-back state does not match current resources.'
        }
    }
    if ($null -ne $Context.ManagedState -and $Context.ManagedState.status -ne 'uninstalled' -and $Context.ManagedState.status -ne 'rolled_back') {
        throw "Managed transaction requires recovery before installation: $($Context.ManagedState.status)"
    }
    if ($Context.Classification -eq 'Pristine') { $mode = 'fresh' }
    elseif ($Context.Classification -eq 'ExactTarget' -and $Adopt) { $mode = 'adopted' }
    elseif ($Context.Classification -eq 'ExactTarget') { throw 'Exact patched resources are unmanaged. Re-run with -AdoptExistingExact only if this state is intentional.' }
    elseif ($Context.Classification -eq 'Mixed') { throw 'Mixed source/target resources are not safe to install.' }
    else { throw 'One or more source resources are unsupported.' }

    Assert-NoGameProcesses
    Assert-TransactionSpace $Manifest $Context
    [void](New-Item -ItemType Directory -Path $Context.StateInstanceRoot -Force)
    [void](Assert-LocalNtfsPath -Path $Context.StateInstanceRoot)
    $transactionId = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '-' + [guid]::NewGuid().ToString('N')
    $dirs = New-StateDirectories $Context.StateInstanceRoot $transactionId
    $operations = @(New-OperationList $Manifest $Context -Adopt:($mode -eq 'adopted'))
    $transaction = [pscustomobject]@{
        state_schema = 1; product = [string]$Manifest.profile.product; version = [string]$Manifest.profile.version
        transaction_id = $transactionId; transaction_relative = $dirs.TransactionRelative; action = 'install'; mode = $mode
        status = 'created'; created_utc = (Get-Date).ToUniversalTime().ToString('o')
        completed_utc = $null; recovered_utc = $null; uninstalled_utc = $null
        failure = $null; rollback_failure = $null
        game_root = $Context.GameRoot; twinkle_root = $Context.TwinkleRoot; operations = $operations
    }
    try {
        Initialize-TransactionAndBackups $transaction $Context $Context.StateInstanceRoot $dirs -AsCurrent
        if ($mode -eq 'adopted') {
            $transaction.status = 'installed'; $transaction.completed_utc = (Get-Date).ToUniversalTime().ToString('o')
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
            Write-Output 'Exact existing patched resources were adopted without rewriting game or Twinkle files.'
            return
        }

        $bf4PrepareProgress = 0
        foreach ($op in @($transaction.operations | Sort-Object commit_order)) {
            $bf4PrepareProgress++
            Write-BF4ItemStatus '准备汉化资源' $bf4PrepareProgress (@($transaction.operations).Count) ([string]$op.id)
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            if($op.kind -eq 'bf4dxr1') {
                $descriptor=Get-ManifestFileById $Manifest ([string]$op.id)
                $patchPath=Resolve-BF4ContainedPath -Root $PackageRoot -RelativePath ([string]$descriptor.patch_path)
                $op.stage_path=New-BF4StreamDeltaStage -Target $target -Patch $patchPath -ExpectedHash ([string]$op.post_sha256)
                $op.stage_verified=$true
                Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
                continue
            }
            $bytes = Get-DesiredBytes $op $Manifest $Context $PackageRoot
            if ([uint64]$bytes.LongLength -ne [uint64]$op.post_size -or -not (Test-HexDigestEqual (Get-BF4Sha256Hex -Bytes $bytes) ([string]$op.post_sha256))) {
                throw "Generated target failed verification: $($op.id)"
            }
            $op.stage_path = New-StageFile $target $bytes ([string]$op.post_sha256)
            $op.stage_verified = $true
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        }
        $transaction.status = 'prepared'; Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        Assert-NoGameProcesses
        $transaction.status = 'committing'; Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        $bf4CommitProgress = 0
        foreach ($op in @($transaction.operations | Sort-Object commit_order)) {
            $bf4CommitProgress++
            Write-BF4ItemStatus '应用汉化' $bf4CommitProgress (@($transaction.operations).Count) ([string]$op.id)
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            $op.commit_pending = $true
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
            Invoke-AtomicReplace ([string]$op.stage_path) $target $op.metadata ([string]$op.pre_sha256) ([string]$op.post_sha256) $op
            $op.commit_pending = $false
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        }
        $transaction.status = 'installed'; $transaction.completed_utc = (Get-Date).ToUniversalTime().ToString('o')
        Remove-Stages @($transaction.operations) $Context
        Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        Write-BF4Status '安装完成。现在可以启动游戏。'
        Write-Output 'BF4 Simplified Chinese Patch installation completed and verified.'
    }
    catch {
        $primary = $_.Exception.Message
        try {
            Write-BF4Status '安装未完成，正在恢复安装前状态，请保持窗口打开。'
            Invoke-InstallRollback $transaction $Context $Context.StateInstanceRoot
            $transaction.status = 'rolled_back'; $transaction.failure = $primary
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
            throw "Installation failed and was rolled back: $primary"
        }
        catch {
            if ($_.Exception.Message -like 'Installation failed and was rolled back:*') { throw }
            $transaction.status = 'rollback_failed'; $transaction.failure = $primary; $transaction.rollback_failure = $_.Exception.Message
            try { Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent } catch {}
            throw "Installation failed; automatic rollback also failed. Use the recorded transaction backups. Install error: $primary; rollback error: $($_.Exception.Message)"
        }
    }
    finally { Remove-Stages @($transaction.operations) $Context }
}

function Invoke-UninstallAction {
    param([object]$Manifest, [object]$Context)
    $state = $Context.ManagedState
    if ($null -eq $state) { throw 'No managed installation state was found. No files were changed.' }
    if ($state.status -eq 'uninstalled' -or $state.status -eq 'rolled_back') {
        if (-not (Test-ManagedCurrentHashes $state $Context -UsePre)) { throw 'Managed state says uninstalled, but resources no longer match its pre-install state.' }
        Write-BF4Status '补丁已卸载，原版文件校验通过。'
        Write-Output 'BF4 Simplified Chinese Patch is already uninstalled and verified.'
        return
    }
    if ($state.status -ne 'installed') { throw "Managed transaction requires recovery before uninstall: $($state.status)" }
    if (-not (Test-ManagedCurrentHashes $state $Context)) { throw 'A managed target file changed after installation; uninstall was safely refused.' }

    if ([string]$state.mode -eq 'adopted') {
        Assert-NoGameProcesses
        $state.status = 'uninstalled'
        $state.uninstalled_utc = (Get-Date).ToUniversalTime().ToString('o')
        $installTxPath = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$state.transaction_relative)
        Write-DurableJson $installTxPath $state
        Write-DurableJson ([System.IO.Path]::Combine($Context.StateInstanceRoot, 'current.json')) $state
        Write-Output 'Adopted exact resources were released from management without rewriting game or Twinkle files.'
        return
    }

    $bf4OriginalProgress = 0
    foreach ($op in @($state.operations)) {
        $bf4OriginalProgress++
        Write-BF4ItemStatus '核对原版备份' $bf4OriginalProgress (@($state.operations).Count) ([string]$op.id)
        $backup = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$op.backup_relative)
        Assert-RegularTargetFile -Path $backup
        if (-not (Test-HexDigestEqual (Get-BF4Sha256Hex -Path $backup) ([string]$op.pre_sha256))) { throw "Original backup is invalid: $($op.id)" }
    }
    Assert-NoGameProcesses
    Assert-TransactionSpace $Manifest $Context
    $transactionId = 'uninstall-' + (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '-' + [guid]::NewGuid().ToString('N')
    $dirs = New-StateDirectories $Context.StateInstanceRoot $transactionId
    $unOps = New-Object 'System.Collections.Generic.List[object]'
    foreach ($sourceOp in @($state.operations)) {
        $unPre=[string]$sourceOp.post_sha256;$unPost=[string]$sourceOp.pre_sha256
        $unPreSize=[uint64]$sourceOp.post_size;$unPostSize=[uint64]$sourceOp.pre_size
        $restoreMeta=$sourceOp.metadata
        if($sourceOp.id -eq 'twinkle-versions') {
            $unPre=$Context.VersionsState.Hash;$unPost=[string]$Manifest.versions.source_sha256
            $unPreSize=$Context.VersionsState.Bytes.LongLength;$unPostSize=$unPreSize
            if($unPre -ne $sourceOp.post_sha256){$restoreMeta=Get-FileMetadata -Path $Context.VersionsState.Path}
        }
        [void]$unOps.Add([pscustomobject]@{
            id = [string]$sourceOp.id; root = [string]$sourceOp.root; relative_path = [string]$sourceOp.relative_path; kind = 'restore'
            commit_order = [int]$sourceOp.commit_order; pre_sha256 = $unPre; post_sha256 = $unPost
            pre_size = $unPreSize; post_size = $unPostSize; original_backup_relative = [string]$sourceOp.backup_relative
            backup_relative = $null; backup_verified = $false; metadata = $null; restore_metadata = $restoreMeta
            stage_path = $null; stage_verified = $false; commit_pending = $false; committed = $false; temporary_access_rules_removed = 0
        })
    }
    $transaction = [pscustomobject]@{
        state_schema = 1; product = [string]$state.product; version = [string]$state.version; transaction_id = $transactionId
        transaction_relative = $dirs.TransactionRelative; action = 'uninstall'; mode = [string]$state.mode; status = 'created'
        created_utc = (Get-Date).ToUniversalTime().ToString('o'); game_root = $Context.GameRoot; twinkle_root = $Context.TwinkleRoot
        completed_utc = $null; recovered_utc = $null; uninstalled_utc = $null
        failure = $null; rollback_failure = $null
        parent_install_relative = [string]$state.transaction_relative; operations = $unOps.ToArray()
    }
    try {
        Initialize-TransactionAndBackups $transaction $Context $Context.StateInstanceRoot $dirs -AsCurrent
        $bf4RestorePrepare = 0
        foreach ($op in @($transaction.operations)) {
            $bf4RestorePrepare++
            Write-BF4ItemStatus '准备原版资源' $bf4RestorePrepare (@($transaction.operations).Count) ([string]$op.id)
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            $original = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$op.original_backup_relative)
            if($op.id -eq 'twinkle-versions') {
                $updates=@($Manifest.versions.updates | ForEach-Object {[pscustomobject]@{path=$_.path;expected_crc32_bzip2=$_.target_crc32_bzip2;target_crc32_bzip2=$_.source_crc32_bzip2}})
                $restoreBytes=Update-BF4VersionsCrcBytes -Bytes ([IO.File]::ReadAllBytes($target)) -Updates $updates -ExpectedUpdateCount 4
                $op.stage_path=New-StageFile $target $restoreBytes ([string]$op.post_sha256)
            } else {
                $op.stage_path = New-CopyStageFile $target $original ([string]$op.post_sha256)
            }
            $op.stage_verified = $true
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        }
        $transaction.status = 'prepared'; Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        Assert-NoGameProcesses
        $transaction.status = 'committing'; Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        $bf4RestoreCommit = 0
        foreach ($op in @($transaction.operations | Sort-Object commit_order -Descending)) {
            $bf4RestoreCommit++
            Write-BF4ItemStatus '恢复原版资源' $bf4RestoreCommit (@($transaction.operations).Count) ([string]$op.id)
            $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
            $op.commit_pending = $true
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
            Invoke-AtomicReplace ([string]$op.stage_path) $target $op.restore_metadata ([string]$op.pre_sha256) ([string]$op.post_sha256) $op
            $op.commit_pending = $false
            Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        }
        $transaction.status = 'resources_restored'
        Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent
        $state.status = 'uninstalled'; $state.uninstalled_utc = (Get-Date).ToUniversalTime().ToString('o')
        Write-DurableJson ([System.IO.Path]::Combine($Context.StateInstanceRoot, 'current.json')) $state
        $installTxPath = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$state.transaction_relative)
        Write-DurableJson $installTxPath $state
        $transaction.status = 'uninstalled'; $transaction.completed_utc = (Get-Date).ToUniversalTime().ToString('o')
        Save-Transaction $transaction $Context.StateInstanceRoot
        Write-BF4Status '卸载完成，已恢复原版资源。'
        Write-Output 'BF4 Simplified Chinese Patch uninstall completed and verified.'
    }
    catch {
        $primary = $_.Exception.Message
        try {
            foreach ($op in @($transaction.operations | Sort-Object commit_order)) {
                $target = Resolve-TargetPath ([string]$op.root) ([string]$op.relative_path) $Context
                $current = Get-BF4Sha256Hex -Path $target
                if (Test-HexDigestEqual $current ([string]$op.pre_sha256)) {
                    Set-FileMetadata -Path $target -Metadata $op.metadata
                    $op.committed = $false; $op.commit_pending = $false; continue
                }
                if (-not (Test-HexDigestEqual $current ([string]$op.post_sha256))) { throw "Unexpected rollback hash: $($op.id)" }
                $backup = Resolve-BF4ContainedPath -Root $Context.StateInstanceRoot -RelativePath ([string]$op.backup_relative)
                $stage = New-CopyStageFile $target $backup ([string]$op.pre_sha256)
                Invoke-AtomicReplace $stage $target $op.metadata ([string]$op.post_sha256) ([string]$op.pre_sha256) $null
                $op.committed = $false
                $op.commit_pending = $false
            }
            $transaction.status = 'rolled_back'; $transaction.failure = $primary
            Save-Transaction $transaction $Context.StateInstanceRoot
            Write-DurableJson ([System.IO.Path]::Combine($Context.StateInstanceRoot, 'current.json')) $state
            throw "Uninstall failed and was rolled back: $primary"
        }
        catch {
            if ($_.Exception.Message -like 'Uninstall failed and was rolled back:*') { throw }
            $transaction.status = 'rollback_failed'; $transaction.failure = $primary; $transaction.rollback_failure = $_.Exception.Message
            try { Save-Transaction $transaction $Context.StateInstanceRoot -AsCurrent } catch {}
            throw "Uninstall failed; automatic rollback also failed. Use the recorded transaction backups. Uninstall error: $primary; rollback error: $($_.Exception.Message)"
        }
    }
    finally { Remove-Stages @($transaction.operations) $Context }
}

$script:operationMutex = $null
$script:ownsOperationMutex = $false
try {
    $bf4ActionNames = @{ Install='安装'; Uninstall='卸载'; Check='检查'; Repair='修复' }
    Write-BF4Status ('开始{0}，正在处理时请保持窗口打开。' -f $bf4ActionNames[$Action])
    # Kernel-only lock: serializes public actions without leaving lock files.
    $script:operationMutex = New-Object System.Threading.Mutex($false, 'Local\BF4SimplifiedChinesePatch-v1.2')
    try { $script:ownsOperationMutex = $script:operationMutex.WaitOne(0) }
    catch [System.Threading.AbandonedMutexException] { $script:ownsOperationMutex = $true }
    if (-not $script:ownsOperationMutex) { throw 'Another patch operation is running. Wait for it to finish before retrying.' }
    $script:PackageRoot = [System.IO.Path]::GetDirectoryName(
        [System.IO.Path]::GetFullPath($MyInvocation.MyCommand.Path)
    )
    $corePath = [System.IO.Path]::Combine($script:PackageRoot, 'BF4Patch.Core.ps1')
    $manifestPath = [System.IO.Path]::Combine($script:PackageRoot, 'package-manifest.json')
    if (-not [System.IO.File]::Exists($corePath)) { throw "Core module is missing: $corePath" }
    . $corePath
    . ([System.IO.Path]::Combine($script:PackageRoot,'BF4Patch.Stream.ps1'))
    . ([System.IO.Path]::Combine($script:PackageRoot,'BF4Patch.Maintenance.ps1'))
    foreach ($requiredFunction in @('Get-BF4Sha256Hex','Assert-BF4SafeRelativePath','Resolve-BF4ContainedPath','Get-BF4Crc32Bzip2','Convert-BF4Crc32Value','Read-BF4VersionsBytes','Update-BF4VersionsCrcBytes','Apply-BF4JsonPatchBytes','Apply-BF4DeltaBytes','Get-BF4FileMetadata','Set-BF4FileMetadata','Enable-BF4TemporaryAtomicReplaceAccess','Invoke-BF4AtomicReplace','Write-BF4DurableJson')) {
        if ($null -eq (Get-Command $requiredFunction -CommandType Function -ErrorAction SilentlyContinue)) { throw "Core interface is missing: $requiredFunction" }
    }
    $manifest = Read-JsonFile -Path $manifestPath
    Write-BF4Status '正在核对补丁包文件...'
    Assert-ManifestShapeAndPackage -Manifest $manifest -PackageRoot $script:PackageRoot
    Assert-NoGameProcesses
    $maintenance = ($Action -eq 'Check' -or $Action -eq 'Repair')
    Write-BF4Status '正在定位游戏并核对资源，大文件校验需要一些时间...'
    $context = Assert-Environment -Manifest $manifest -GameOverride $GameRoot -TwinkleOverride $TwinkleRoot -StateOverride $StateRoot -AllowKnownMismatch:$maintenance
    if ($maintenance) {
        if ($AdoptExistingExact) { throw '-AdoptExistingExact is valid only with -Action Install.' }
        $result = Invoke-MaintenanceAction -Action $Action -Manifest $manifest -Context $context -PackageRoot $script:PackageRoot
        exit $result
    }
    Assert-MetadataRestoreAuthority -Context $context
    $pendingStatuses = @('backup_manifest_written', 'backed_up', 'prepared', 'committing', 'resources_restored', 'rolling_back')
    if ($null -ne $context.ManagedState -and $pendingStatuses -contains [string]$context.ManagedState.status) {
        [void](Invoke-IncompleteTransactionRecovery -Manifest $manifest -Context $context)
        $context = Assert-Environment -Manifest $manifest -GameOverride $GameRoot -TwinkleOverride $TwinkleRoot -StateOverride $StateRoot
    }
    if ($Action -eq 'Install') { Invoke-InstallAction $manifest $context $script:PackageRoot -Adopt:$AdoptExistingExact }
    else {
        if ($AdoptExistingExact) { throw '-AdoptExistingExact is valid only with -Action Install.' }
        Invoke-UninstallAction $manifest $context
    }
    exit 0
}
catch {
    Write-BF4Status ('操作未完成：' + $_.Exception.Message)
    Write-Error $_.Exception.Message
    exit 1
}
finally {
    if ($script:ownsOperationMutex) { $script:operationMutex.ReleaseMutex() }
    if ($null -ne $script:operationMutex) { $script:operationMutex.Dispose() }
}
