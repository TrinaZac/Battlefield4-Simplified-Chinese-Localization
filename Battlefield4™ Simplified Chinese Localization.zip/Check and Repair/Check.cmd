@echo off
setlocal
echo [BF4] Starting Check. Please wait...
if not exist "%~dp0..\Core File\Installer.ps1" (
  echo [BF4] Installer.ps1 was not found. Extract the complete ZIP first.
  if "%~1"=="" pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\Core File\Installer.ps1" -Action Check %*
set "_bf4_exit=%errorlevel%"
if "%~1"=="" pause
exit /b %_bf4_exit%
