@echo off
setlocal
echo [BF4] Starting Install. Please wait...
if not exist "%~dp0Core File\Installer.ps1" (
  echo [BF4] Installer.ps1 was not found. Extract the complete ZIP first.
  if "%~1"=="" pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Core File\Installer.ps1" -Action Install %*
set "_bf4_exit=%errorlevel%"
if "%~1"=="" pause
exit /b %_bf4_exit%
